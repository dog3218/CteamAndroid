package com.example.show;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.show.DTO.CommunityDTO;

import java.util.ArrayList;

public class Com_List_Activity extends AppCompatActivity {
    Toolbar toolbar;


    // 공연 정보 붙여줄 아이템 선언
    ListView listView;
    CommAdapter commAdapter;
    ArrayList<CommunityDTO> dtos;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_com_list);
        super.onCreate(savedInstanceState);


        toolbar = findViewById(R.id.com_list_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        toolbar.setTitle("리스트");
        // 여기 까지 상단 툴바 --------------------------------------------------------

        //리스트 생성
        dtos = new ArrayList<>();
        listView = findViewById(R.id.com_list_listView);

        commAdapter = new CommAdapter(Com_List_Activity.this, dtos);
        listView.setAdapter(commAdapter);

        // listView를 클릭했을 때 이벤트 추가
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 어떤 값을 선택함

                Intent intent = new Intent(Com_List_Activity.this, Com_Detail_Activity.class);
                intent.putExtra("dto", dtos);

            }
        });
    }
}
