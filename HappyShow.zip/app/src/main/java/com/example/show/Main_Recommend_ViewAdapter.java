package com.example.show;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.show.DTO.BoardDTO;
import com.example.show.DTO.Main_Recommend_DTO;

import java.util.ArrayList;

public class Main_Recommend_ViewAdapter extends BaseAdapter{

    Context context;
    ArrayList<BoardDTO> dtos;

    LayoutInflater inflater;

    public Main_Recommend_ViewAdapter(Context context, ArrayList<BoardDTO> dtos) {
        this.context = context;
        this.dtos = dtos;

        this.inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public void addDto(BoardDTO dto) {dtos.add(dto);}

    @Override
    public int getCount() {
        return dtos.size();
    }

    @Override
    public Object getItem(int i) {
        return dtos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        RankViewHoler viewHoler;

        if(view == null) {
            view = inflater.inflate(R.layout.main_view_rank, viewGroup, false);

            viewHoler = new RankViewHoler();

            viewHoler.iv_rank_img = view.findViewById(R.id.iv_rank_img);
            viewHoler.tv_rank_name = view.findViewById(R.id.tv_rank_name);
            viewHoler.tv_rank_date = view.findViewById(R.id.tv_rank_date);
            viewHoler.tv_rank_location = view.findViewById(R.id.tv_rank_location);

            view.setTag(viewHoler);
        }else {
            viewHoler = (RankViewHoler) view.getTag();
        }

        BoardDTO dto = dtos.get(i);



        return view;
    }

    public class RankViewHoler {
        public ImageView iv_rank_img;
        public TextView tv_rank_name, tv_rank_date, tv_rank_location;
    }
}



