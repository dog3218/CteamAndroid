package com.example.show;

import android.content.Context;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.example.show.DTO.BoardDTO;

import java.util.ArrayList;

public class BoardAdapter extends BaseAdapter {
    private static final String TAG = "main:BoardAdapter";
    //메인에서 넘겨받을 것 -> 생성자를 만든다.
    Context context;
    ArrayList<BoardDTO> dtos;

    //화면을 붙이기 위한 화면생성
    LayoutInflater  inflater;

    public BoardAdapter(Context context, ArrayList<BoardDTO> dtos) {
        this.context = context;
        this.dtos = dtos;

        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    //=============================================================//
    //메소드를 만들 때는 무조건 여기에 생성한다(adapter)
    //하나의 dto 추가하기 (SingerDTO)
    public void addDto(BoardDTO dto) {
        dtos.add(dto);
    }

    //dtos의 모든 내용 지우기
    public void removeDtos(){
        dtos.clear();
    }
    //=============================================================//


    //dtos에 저장된 dto 개수
    @Override
    public int getCount() {
        return dtos.size();
    }

    //dtos의 특정위치에 있는 dto 가져오기(SingerDTO)
    @Override
    public Object getItem(int position) {
        return dtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    //☆가장 중요☆ : 화면을 생성하고 특정 뷰에 대한 클릭이벤트를 만들 수 있다.
    //만약 화면 5개를 생성한다면 getView가 5번 실행된다.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "getView: " + position);

        ShowViewHolder viewHolder;

        //캐시된 뷰가 없을 경우 새로 뷰홀더를 생성하고 있으면 그 뷰를 재활용한다.
        if (convertView == null) {
            //화면을 새로 만든다
            convertView = inflater.inflate(R.layout.main_showview, parent, false);

            viewHolder = new ShowViewHolder();
            //붙힌 화면과 아래에 생성한 뷰홀더를 연결한다.
            viewHolder.main_home_slidePoster = convertView.findViewById(R.id.main_home_slidePoster);
            viewHolder.main_home_board_title_tv = convertView.findViewById(R.id.main_home_board_title_tv);
            viewHolder.main_home_board_no_tv = convertView.findViewById(R.id.main_home_board_no_tv);
            viewHolder.viewLayout = convertView.findViewById(R.id.viewLayout);

            convertView.setTag(viewHolder);
        }else { //캐시된 뷰가 있을 경우 이미 생성된 뷰홀더를 사용한다.
            viewHolder = (ShowViewHolder) convertView.getTag();
        }

        //선택한 dto 데이터를 가져오기
        BoardDTO dto = dtos.get(position);

        String on_off = dto.getOn_offline();
        if(on_off.equals("n")){
            viewHolder.viewLayout.setBackgroundResource(R.drawable.red_edittext);
        }else if(on_off.equals("f")){
            viewHolder.viewLayout.setBackgroundResource(R.drawable.green_edittext);
        }else{
            viewHolder.viewLayout.setBackgroundResource(R.drawable.orange_edittext);
        }

        Log.d(TAG, "getView: " + dto.getNo());
        Log.d(TAG, "getView: " + dto.getEventnm());
        //int resImg = dto.getNo();

        //화면에 데이터를 연결하기
        // viewHolder.slidePoster.setImageResource(resImg);

        viewHolder.main_home_board_title_tv.setText(dtos.get(position).getEventnm());
        viewHolder.main_home_board_no_tv.setText(String.valueOf(dtos.get(position).getNo()));
        //view

        Glide.with(context).load(dto.getFilepath()).into(viewHolder.main_home_slidePoster);

        return convertView;
    }

    /*3.xml 파일에서 사용된 모든 변수를 Adapter에서 클래스로 선언한다*/
    public class ShowViewHolder{
        public ImageView main_home_slidePoster;
        public TextView main_home_board_title_tv, main_home_board_no_tv;
        public LinearLayout viewLayout;
    }
}
