package com.example.show;

import static android.view.View.FOCUS_UP;

import android.content.Context;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ScrollView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class Main_Home extends Fragment {

    Main_Home_Opera main_home_opera;
    Main_Home_All main_home_all;
    Main_Home_Concert main_home_concert;
    Main_Home_Musical main_home_musical;
    Main_Home_Play main_home_play;
    Main_Home_Exhibition main_home_exhibition;
    Fragment selectFragment= null;

    TabLayout main_home_tabs;
    FrameLayout main_home_contain;

    MainActivity activity;

    GridView gridView;
    ImageView main_home_imageView;

//11.26============================================================================================
    Button btn_Top;
//11.26============================================================================================

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity= (MainActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_home, container, false);

        main_home_opera = new Main_Home_Opera();
        main_home_concert = new Main_Home_Concert();
        main_home_all = new Main_Home_All();
        main_home_exhibition = new Main_Home_Exhibition();
        main_home_musical = new Main_Home_Musical();
        main_home_play = new Main_Home_Play();
        gridView = rootView.findViewById(R.id.main_home_all_gridView);
//11.26============================================================================================

        btn_Top = rootView.findViewById(R.id.btn_Top);



        main_home_imageView = rootView.findViewById(R.id.main_home_imageView);

        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();
//11.26============================================================================================

        main_home_tabs = rootView.findViewById(R.id.main_home_tabs);
        main_home_tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        //11.26============================================================================================
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_all.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_musical).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_musical.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_opera).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_opera.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_play).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_play.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_exhibition).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_exhibition.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 5:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_concert).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_concert.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });




        return rootView;
    }
//11.26============================================================================================
    public void topImgDisappear(int state){
        if(state == 1){
            main_home_imageView.setVisibility(View.GONE);
//            main_home_all.set
        }else if(state == 0){
            main_home_imageView.setVisibility(View.VISIBLE);
            main_home_imageView.setImageResource(R.drawable.opera_poster);
        }

    }
//11.26============================================================================================
}
