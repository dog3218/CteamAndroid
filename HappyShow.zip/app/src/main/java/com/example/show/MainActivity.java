package com.example.show;

import static com.example.show.Common.CommonMethod.loginDTO;
import static com.example.show.Common.CommonMethod.memberallDTO;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.Toast;

import com.example.show.ATask.MemberSelect;
import com.example.show.DTO.BoardDTO;
import com.example.show.DTO.MemberDTO;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "mainActivity";
    //백버튼
    private long backKeyPressedTime = 0;

    // 공연 정보를 붙여줄 아이템들 선언

    ArrayList<BoardDTO> dtos;
    BoardAdapter adapter;


    // 여기부터는 위에 상단 탭--------------------------------------

    Toolbar toolbar;




    // 아래 네비게이션 바 !--------------------------------------------------------------
    // 여긴 네비게이션 fragment 임

    Main_Home home;
    Main_Show interest;
    Main_Recommend recommend;
    Main_More_Admin more_admin;
    Main_Community community;
    Main_More_User more_user;
    Main_More_Director more_director;

    // 여기가 아래 네비게이션 바
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //공연정보 이미지가 데이터베이스에 있을 경우
        /*imageView = findViewById(R.id.imageView);
        Glide.with(MainActivity.this)
                .load(loginDTO.getImgpath())
                .circleCrop()
                .into(imageView);*/

        dtos = new ArrayList<>();


        //어댑터 객체 생성
        adapter = new BoardAdapter(MainActivity.this, dtos);



        Log.d(TAG, "onCreate: 확인");
        Log.d(TAG, "onCreate: 확인");









        // 여기서 부터는 상단 탭 -----------------------


        toolbar = findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);



        // 아래 네비게이션 bar

        home = new Main_Home();
        interest = new Main_Show();
        recommend = new Main_Recommend();
        more_admin = new Main_More_Admin();
        more_user = new Main_More_User();
        community = new Main_Community();
        more_director = new Main_More_Director();

        // 처음 메인화면 초기화
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_contain, home).commit();


        bottomNavigationView = findViewById(R.id.main_bot_navi);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.main_contain, home).commit();
                        toolbar.setTitle(null);
                        break;

                    case R.id.interest_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.main_contain, interest).commit();
                        toolbar.setTitle("나의 관심 공연");
                        break;

                    case R.id.recommend_tab:
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.main_contain, recommend).commit();
                        toolbar.setTitle("추천");
                        break;


                    case R.id.community_tab:_tab:
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_contain, community).commit();
                        toolbar.setTitle("커뮤니티");


                        break;




                    case R.id.more_tab:
                        toolbar.setTitle("더보기");
                        if (loginDTO.getType().equals("admin")){
                          getSupportFragmentManager().beginTransaction()
                                .replace(R.id.main_contain, more_admin).commit();}
                        else if((loginDTO.getType().equals("director"))) {
                            getSupportFragmentManager().beginTransaction().replace(R.id.main_contain, more_director).commit();
                        }else {
                            getSupportFragmentManager().beginTransaction().replace(R.id.main_contain, more_user).commit();
                        }




                        break;
                }

                return true;
            }
        });

    } //oncreate

    //백버튼
    @Override
    public void onBackPressed() {
        //기존 기능 제거
        //super.onBackPressed();
        if(System.currentTimeMillis() > backKeyPressedTime + 2000) {
            backKeyPressedTime = System.currentTimeMillis();
            Toast.makeText(this, "한 번 더 누르면 종료됩니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        //한번 더 누르면 종료
        if (System.currentTimeMillis() <= backKeyPressedTime + 2000) {
            finish();
        }
    }

    // 옵션바 옵션메뉴 붙인거--------------------------------------------------------------------------------------
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.main_top, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_search:
                Intent intent = new Intent(MainActivity.this, SearchActivity.class);


                startActivity(intent);



        }


        return super.onOptionsItemSelected(item);
    }

    public void topImageDis(int state){
        home.topImgDisappear(state);
    }


}