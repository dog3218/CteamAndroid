package com.example.show;

import static com.example.show.Common.CommonMethod.isNetworkConnected;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;

import com.example.show.ATask.BoardSelect;
import com.example.show.DTO.BoardDTO;


import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Main_Home_All extends Fragment {
    private static final String TAG = "main:Main_Home_All";
    
    GridView gridView;

    BoardAdapter adapter;
    ArrayList<BoardDTO> dtos;
    MainActivity activity;
    String type;

    Main_Home main_home;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_home_all, container, false);
        dtos = new ArrayList<>();
        activity = (MainActivity) getActivity();
        gridView = rootView.findViewById(R.id.main_home_all_gridView);
        type = "all";


        adapter = new BoardAdapter(activity, dtos);
        gridView.setAdapter(adapter);

//11.26============================================================================================

        gridView.setOnScrollChangeListener(new View.OnScrollChangeListener() {

            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                Log.d(TAG, "onScrollChange: " + gridView.getFirstVisiblePosition());

                if(gridView.getFirstVisiblePosition() > 0){
                    activity.topImageDis(1);
                }else if(gridView.getFirstVisiblePosition() == 0){
                    activity.topImageDis(0);
                }

            }
        });

//11.26============================================================================================
        //어댑터에 생성한 메소드 addDto를 이용하여 dtos에 데이터를 추가한다.

        //서버에 멤버 ArrayList를 요구
        if(isNetworkConnected(getContext()) == true){
            //AsyncTask 생성
            BoardSelect boardSelect = new BoardSelect(dtos, adapter, type);
            try {
                boardSelect.execute().get();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }

        //리스트뷰는 아이템 클릭 이벤트를 제공해준다.
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BoardDTO dto = (BoardDTO) adapter.getItem(position);

                Intent intent = new Intent(getActivity(), InformationActivity.class);
                intent.putExtra("dto", position);
                startActivity(intent);
            }
        });


        return rootView;
    }
//11.26============================================================================================
    public void positionTop(int position) {
        gridView.smoothScrollToPosition(position);
    }
//11.26============================================================================================
}
