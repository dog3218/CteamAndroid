package com.example.show;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class PromotionActivity extends AppCompatActivity {
    Fragment promoFragment1;
    Fragment promoFragment2;
    ImageView iv_promo;
    private static final int REQUEST_CODE = 0;
    TextView et_promo_subject, et_promo_date, et_promo_writedate, et_promo_name;
    CheckBox check_promo;
    Button btn_promo, btn_promo_submit, btn_promo_reset;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promotion);

        //갤러리에서 사진 가져오기
        iv_promo = findViewById(R.id.iv_promo);

        iv_promo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });


        promoFragment1 = new Promo_Fragment1();
        promoFragment2 = new Promo_Fragment2();

        getSupportFragmentManager().findFragmentById(R.id.contain_promo1);

        getSupportFragmentManager().findFragmentById(R.id.contain_promo2);



        //작성버튼
        findViewById(R.id.btn_promo_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        //초기화버튼
        findViewById(R.id.btn_promo_reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_promo_subject = findViewById(R.id.et_promo_subject);
                et_promo_date = findViewById(R.id.et_promo_date);
                et_promo_writedate = findViewById(R.id.et_promo_writedate);
                et_promo_name = findViewById(R.id.et_promo_name);
                iv_promo = findViewById(R.id.iv_promo);

                et_promo_subject.setText("");
                et_promo_date.setText("");
                et_promo_writedate.setText("");
                et_promo_writedate.setText("");
                iv_promo.setImageResource(R.drawable.ic_launcher_foreground);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                try {
                    InputStream in = getContentResolver().openInputStream(data.getData());

                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();

                    iv_promo.setImageBitmap(img);
                } catch (Exception e) {

                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "사진 선택 취소", Toast.LENGTH_LONG).show();
            }
        }
    }
}

