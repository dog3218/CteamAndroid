package com.example.show;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.DTO.Main_Recommend_DTO;

import java.util.ArrayList;

public class Main_Recommend_Fragment extends Fragment {

    ListView list_rank;
    Main_Recommend_ViewAdapter adapter;
    ArrayList<Main_Recommend_DTO> dtos;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_recommend_fragment_rank, container, false);

        //조회 선택(조회순, 좋아요순, 리뷰순)
        Spinner spinner_rank = rootView.findViewById(R.id.spinner_rank);
        ArrayAdapter rankAdaper = ArrayAdapter.createFromResource(getActivity(), R.array.rank, android.R.layout.simple_spinner_item);
        rankAdaper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_rank.setAdapter(rankAdaper);
        spinner_rank.setSelection(0);

        dtos = new ArrayList<>();

        list_rank = rootView.findViewById(R.id.list_rank);

//        adapter = new Main_Recommend_ViewAdapter(getActivity(), dtos);
//        adapter.addDto(new Main_Recommend_DTO("공연명1", "2021/01/01", "위치1", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명2", "2021/01/01", "위치2", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명3", "2021/01/01", "위치3", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명4", "2021/01/01", "위치4", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명5", "2021/01/01", "위치5", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명6", "2021/01/01", "위치6", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명7", "2021/01/01", "위치7", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명8", "2021/01/01", "위치8", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명9", "2021/01/01", "위치9", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명10", "2021/01/01", "위치10", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명11", "2021/01/01", "위치11", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명12", "2021/01/01", "위치12", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명13", "2021/01/01", "위치13", R.drawable.ic_launcher_foreground));
//        adapter.addDto(new Main_Recommend_DTO("공연명14", "2021/01/01", "위치14", R.drawable.ic_launcher_foreground));

        list_rank.setAdapter(adapter);

        list_rank.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Main_Recommend_DTO rankDTO = (Main_Recommend_DTO) adapter.getItem(position);

                Intent intent = new Intent(getActivity(), InformationActivity.class);
                intent.putExtra("dto", position);
                startActivity(intent);

            }
        });

        return rootView;
    }



}