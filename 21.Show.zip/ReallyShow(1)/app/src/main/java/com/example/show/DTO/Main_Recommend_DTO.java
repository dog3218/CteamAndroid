package com.example.show.DTO;

import java.io.Serializable;

public class Main_Recommend_DTO implements Serializable {

    private String name, date, location;
    private int resID;

    public Main_Recommend_DTO(String name, String date, String location, int resID) {
        this.name = name;
        this.date = date;
        this.location = location;
        this.resID = resID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getResID() {
        return resID;
    }

    public void setResID(int resID) {
        this.resID = resID;
    }
}
