package com.example.show.DTO;

import java.io.Serializable;

public class BoardDTO implements Serializable {
    private String eventnm,	opar, eventco, eventstartdate, eventenddate, eventstarttime, eventendtime, chrgeinfo, mnnst, auspcinstt, phonenumber, suprtinstt, seatnumber, admfee,
            entncage, dscntinfo, atpn, homepageurl, advantkinfo, prkplceyn, rdnmadr, lnmadr, latitude, longitude, referencedate, filepath, postdate, writer, on_offline;
    private int no, post_able, readcnt;

    public BoardDTO(String eventnm, int no, String filepath, String on_offline) {
        this.eventnm = eventnm;
        this.no = no;
        this.filepath = filepath;
        this.on_offline = on_offline;
    }

    public String getEventnm() {
        return eventnm;
    }

    public void setEventnm(String eventnm) {
        this.eventnm = eventnm;
    }

    public String getOpar() {
        return opar;
    }

    public void setOpar(String opar) {
        this.opar = opar;
    }

    public String getEventco() {
        return eventco;
    }

    public void setEventco(String eventco) {
        this.eventco = eventco;
    }

    public String getEventstartdate() {
        return eventstartdate;
    }

    public void setEventstartdate(String eventstartdate) {
        this.eventstartdate = eventstartdate;
    }

    public String getEventenddate() {
        return eventenddate;
    }

    public void setEventenddate(String eventenddate) {
        this.eventenddate = eventenddate;
    }

    public String getEventstarttime() {
        return eventstarttime;
    }

    public void setEventstarttime(String eventstarttime) {
        this.eventstarttime = eventstarttime;
    }

    public String getEventendtime() {
        return eventendtime;
    }

    public void setEventendtime(String eventendtime) {
        this.eventendtime = eventendtime;
    }

    public String getChrgeinfo() {
        return chrgeinfo;
    }

    public void setChrgeinfo(String chrgeinfo) {
        this.chrgeinfo = chrgeinfo;
    }

    public String getMnnst() {
        return mnnst;
    }

    public void setMnnst(String mnnst) {
        this.mnnst = mnnst;
    }

    public String getAuspcinstt() {
        return auspcinstt;
    }

    public void setAuspcinstt(String auspcinstt) {
        this.auspcinstt = auspcinstt;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getSuprtinstt() {
        return suprtinstt;
    }

    public void setSuprtinstt(String suprtinstt) {
        this.suprtinstt = suprtinstt;
    }

    public String getSeatnumber() {
        return seatnumber;
    }

    public void setSeatnumber(String seatnumber) {
        this.seatnumber = seatnumber;
    }

    public String getAdmfee() {
        return admfee;
    }

    public void setAdmfee(String admfee) {
        this.admfee = admfee;
    }

    public String getEntncage() {
        return entncage;
    }

    public void setEntncage(String entncage) {
        this.entncage = entncage;
    }

    public String getDscntinfo() {
        return dscntinfo;
    }

    public void setDscntinfo(String dscntinfo) {
        this.dscntinfo = dscntinfo;
    }

    public String getAtpn() {
        return atpn;
    }

    public void setAtpn(String atpn) {
        this.atpn = atpn;
    }

    public String getHomepageurl() {
        return homepageurl;
    }

    public void setHomepageurl(String homepageurl) {
        this.homepageurl = homepageurl;
    }

    public String getAdvantkinfo() {
        return advantkinfo;
    }

    public void setAdvantkinfo(String advantkinfo) {
        this.advantkinfo = advantkinfo;
    }

    public String getPrkplceyn() {
        return prkplceyn;
    }

    public void setPrkplceyn(String prkplceyn) {
        this.prkplceyn = prkplceyn;
    }

    public String getRdnmadr() {
        return rdnmadr;
    }

    public void setRdnmadr(String rdnmadr) {
        this.rdnmadr = rdnmadr;
    }

    public String getLnmadr() {
        return lnmadr;
    }

    public void setLnmadr(String lnmadr) {
        this.lnmadr = lnmadr;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getReferencedate() {
        return referencedate;
    }

    public void setReferencedate(String referencedate) {
        this.referencedate = referencedate;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }

    public String getPostdate() {
        return postdate;
    }

    public void setPostdate(String postdate) {
        this.postdate = postdate;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public int getPost_able() {
        return post_able;
    }

    public void setPost_able(int post_able) {
        this.post_able = post_able;
    }

    public int getReadcnt() {
        return readcnt;
    }

    public void setReadcnt(int readcnt) {
        this.readcnt = readcnt;
    }

    public String getOn_offline() {
        return on_offline;
    }

    public void setOn_offline(String on_offline) {
        this.on_offline = on_offline;
    }
}