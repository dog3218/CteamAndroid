package com.example.show;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.show.DTO.Com_ReView_DTO;

import java.util.ArrayList;

/*4. 선언한 클래스와 xml 파일을 이용하여 화면에 adapter에서 생성한다.*/
public class Com_ReView_Adapter extends BaseAdapter {
    private static final String TAG = "main:Com_ReView_Adapter";

    //메인에서 넘겨받을 것 -> 생성자를 만든다.
    Context context;
    ArrayList<Com_ReView_DTO> dtos;

    //화면을 붙이기 위한 화면생성
    LayoutInflater  inflater;

    public Com_ReView_Adapter(Context context, ArrayList<Com_ReView_DTO> dtos) {
        this.context = context;
        this.dtos = dtos;

        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    //사용자 사용 불가 메소드(관리자만 사용가능)
    //=============================================================//
    //dto 추가(Com_ReViewDTO)
    public void addDto(Com_ReView_DTO dto) {
        dtos.add(dto);
    }

    //dtos의 모든 내용 지우기
    public void removeDtos(){
        dtos.clear();
    }
    //=============================================================//


    //dtos에 저장된 dto 개수
    @Override
    public int getCount() {
        return dtos.size();
    }

    //dtos의 특정위치에 있는 dto 가져오기(SingerDTO)
    @Override
    public Object getItem(int position) {
        return dtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //☆가장 중요☆ : 화면을 생성하고 특정 뷰에 대한 클릭이벤트를 만들 수 있다.
    //만약 화면 5개를 생성한다면 getView가 5번 실행된다.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "getView: " + position);

        ShowViewHolder viewHolder;

        //캐시된 뷰가 없을 경우 새로 뷰홀더를 생성하고 있으면 그 뷰를 재활용한다.
        if (convertView == null) {
            //화면을 새로 만든다
            convertView = inflater.inflate(R.layout.com_review, parent, false);

            viewHolder = new ShowViewHolder();
            //붙힌 화면과 아래에 생성한 뷰홀더를 연결한다.
            viewHolder.re_userId_tv = convertView.findViewById(R.id.re_userId_tv);
            viewHolder.re_title_tv = convertView.findViewById(R.id.re_title_tv);
            viewHolder.re_content_tv = convertView.findViewById(R.id.re_content_tv);
            viewHolder.re_wd_tv = convertView.findViewById(R.id.re_wd_tv);

            convertView.setTag(viewHolder);
        }else { //캐시된 뷰가 있을 경우 이미 생성된 뷰홀더를 사용한다.
            viewHolder = (ShowViewHolder) convertView.getTag();
        }

        //선택한 dto 데이터를 가져오기
        Com_ReView_DTO dto = dtos.get(position);
        String userId = dto.getUserId();
        String title = dto.getTitle();
        String content = dto.getContent();
        String writedate = dto.getWritedate();

        //화면에 데이터를 연결하기
        viewHolder.re_userId_tv.setText(userId);
        viewHolder.re_title_tv.setText(title);
        viewHolder.re_content_tv.setText(content);
        viewHolder.re_wd_tv.setText(writedate);

        //이미지 클릭시 이벤트 걸어주기
        /*viewHolder.slidePoster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "선택 : " + position
                        + "\n이름 : " + dtos.get(position).getTitle(),Toast.LENGTH_SHORT).show();

                //이미지뷰를 동적으로 생성해서 해당 이미지 보여줌
                //popUpImg(dtos.get(position).getRegId());
                popUpImgXml(dtos.get(position));
            }
        });*/


        return convertView;
    }

        /*3.xml 파일에서 사용된 모든 변수를 Adapter에서 클래스로 선언한다*/
    public class ShowViewHolder{
        public TextView re_userId_tv, re_title_tv, re_content_tv, re_wd_tv;
    }
}
