package com.example.show;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class Main_Show extends Fragment {

    Main_Show_Play main_show_play;
    Main_Show_Opera main_show_opera;
    Main_Show_Musical main_show_musical;
    Main_Show_Exhibition main_show_exhibition;
    Main_Show_Concert main_show_concert;



    TabLayout main_show_tabs;

    MainActivity activity;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity) getActivity();
    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_show, container, false);

        main_show_musical = new Main_Show_Musical();
        main_show_concert = new Main_Show_Concert();
        main_show_play = new Main_Show_Play();
        main_show_exhibition = new Main_Show_Exhibition();
        main_show_opera = new Main_Show_Opera();


        main_show_tabs = rootView.findViewById(R.id.main_show_tabs);
        main_show_tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_show_contain, main_show_musical).commit();
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_show_contain, main_show_opera).commit();
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_show_contain, main_show_play).commit();
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_show_contain, main_show_exhibition).commit();
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_show_contain, main_show_concert).commit();
                        break;
                }




            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });



        return rootView;

    }
}
