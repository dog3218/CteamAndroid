package com.example.show.BottomNavi;

import static com.example.show.Common.CommonMethod.loginDTO;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.LoginActivity;
import com.example.show.MainActivity;
import com.example.show.PromotionActivity;
import com.example.show.R;

public class Main_More_Director extends Fragment {

    MainActivity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        activity = (MainActivity) getActivity();
    }   // onAttach

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_more_direct, container, false);

        rootView.findViewById(R.id.more_direct_promotion).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PromotionActivity.class);
                String email= loginDTO.getEmail();
                intent.putExtra("email",email);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.director_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "성공적으로 로그아웃 되었습니다.", Toast.LENGTH_SHORT).show();
                loginDTO = null;
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);

            }
        });

        return rootView;
    }
}
