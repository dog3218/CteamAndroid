package com.example.show.ATask;

import static com.example.show.Common.CommonMethod.ipConfig;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;

import com.example.show.DTO.NoticeDTO;
import com.example.show.Adapter.NoticeAdapter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;

public class NoticeSelect extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "main:NoticeSelect";

    ArrayList<NoticeDTO> dtos;
    NoticeAdapter adapter;

    private ArrayList<String> arrayGroup;
    private HashMap<String, ArrayList<String> > arrayChild;

    // 반드시 선언해야 할것들 : 무조건 해야함  복,붙
    HttpClient httpClient;       // 클라이언트 객체
    HttpPost httpPost;           // 클라이언트에 붙일 본문
    HttpResponse httpResponse;   // 서버에서의 응답받는 부분
    HttpEntity httpEntity;       // 응답내용

    public NoticeSelect(ArrayList<NoticeDTO> dtos, NoticeAdapter adapter, ArrayList<String> arrayGroup, HashMap<String, ArrayList<String>> arrayChild) {
        this.dtos = dtos;
        this.adapter = adapter;
        this.arrayGroup = arrayGroup;
        this.arrayChild = arrayChild;
    }

    // 실질적으로 일을하는 부분 : 접근 못함(textView, button)
    @Override
    protected Void doInBackground(Void... voids) {

        try {
            // MultipartEntityBuilder 생성 : 무조건 해야함  복,붙
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.setCharset(Charset.forName("UTF-8"));

            // 전송
            // 전송 url : 우리가 수정해야 하는 부분
            String postURL = ipConfig + "anNoticeSelect";
            // 그대로 사용  복,붙
            InputStream inputStream = null;
            httpClient = AndroidHttpClient.newInstance("Android");
            httpPost = new HttpPost(postURL);
            httpPost.setEntity(builder.build());
            httpResponse = httpClient.execute(httpPost);  // 보내고 응답 받는 부분
            httpEntity = httpResponse.getEntity();    // 응답내용을 저장
            inputStream = httpEntity.getContent();    // 응답내용을 inputStream 에 넣음

            // 데이터가 ArrayList<DTO> 형태일때
            readJsonStream(inputStream);


        }catch (Exception e){
            e.getMessage();
        }finally {
            if(httpEntity != null){
                httpEntity = null;
            }
            if(httpResponse != null){
                httpResponse = null;
            }
            if(httpPost != null){
                httpPost = null;
            }
            if(httpClient != null){
                httpClient = null;
            }
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);

        Log.d(TAG, "onPostExecute: List Select Complete !!!" );

        // 데이터가 새로 삽입되어서 화면 갱신을 해준다
       // adapter.notifyDataSetChanged();
    }

    public void readJsonStream(InputStream inputStream) throws IOException {
        JsonReader reader = new JsonReader(new InputStreamReader(inputStream, "UTF-8"));
        try {
            reader.beginArray();
            int count =0;
            while (reader.hasNext()) {
                dtos.add(readMessage(reader, count));
                count++;
            }
            reader.endArray();
        } finally {
            reader.close();
        }
    }

    public NoticeDTO readMessage(JsonReader reader, int count) throws IOException {
        String title="", content="", writedate="", writer="";
        int importance = 0 ,readcnt =0;
        reader.beginObject();
        while (reader.hasNext()){
            String readStr = reader.nextName();
            if(readStr.equals("title")){
                title= reader.nextString();
                arrayGroup.add(title);
            }else if(readStr.equals("content")){
                content = reader.nextString();
                ArrayList<String>  array = new ArrayList<>();
                array.add(content);
                arrayChild.put(arrayGroup.get(count), array);
                Log.d(TAG, "readMessage 1: " + arrayChild.get(array));
            }else if(readStr.equals("writedate")){
                writedate = reader.nextString();
            }else if(readStr.equals("writer")){
                writer = reader.nextString();
            }else if(readStr.equals("importance")){
                importance = Integer.parseInt(reader.nextString());
            }else if (readStr.equals("readcnt")){
                readcnt= Integer.parseInt(reader.nextString());

            }else{
                reader.skipValue();
            }
        }
        reader.endObject();
        Log.d(TAG, "readMessage: " +title + ", " + content + ", " +  arrayChild.size()  );
       // Log.d(TAG,  nickname + "," + password + "," + address + "," + name+"," + email +"," +idnumber + ","+filename +"," +joindate);
        return new NoticeDTO(title, content, writedate, writer, importance, readcnt);
    }

}