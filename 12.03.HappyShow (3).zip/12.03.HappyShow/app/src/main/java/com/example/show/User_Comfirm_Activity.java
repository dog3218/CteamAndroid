package com.example.show;

import static com.example.show.Common.CommonMethod.loginDTO;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.show.ATask.LoginSelect;
import com.example.show.DTO.MemberDTO;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class User_Comfirm_Activity extends AppCompatActivity {
    private static final String TAG = "user_confirm";


    TextView user_tvID_confirm_id;
    EditText user_etPW_confirm_pw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_comfirm);

        user_tvID_confirm_id = findViewById(R.id.user_tvID_confirm_id);
        user_etPW_confirm_pw = findViewById(R.id.user_etPW_confirm_pw);

        user_tvID_confirm_id.setText(loginDTO.getEmail());

        Intent intent = getIntent();
        String pw = loginDTO.getPassword();


        //확인버튼
        findViewById(R.id.user_btn_confirm_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String pass = user_etPW_confirm_pw.getText().toString();
                //------------------------------------------------------------------------------
                if(pw.equals(pass)) {
                    Intent inte = new Intent(User_Comfirm_Activity.this, Certificate_Director_Activity.class);
                    startActivity(inte);


                }else {
                    Toast.makeText(User_Comfirm_Activity.this, "비밀번호가 일치하지않습니다.", Toast.LENGTH_SHORT).show();
                }




            }
        });

        //리셋버튼
        findViewById(R.id.user_btn_confirm_reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_etPW_confirm_pw.setText("");
            }
        });

    }
}