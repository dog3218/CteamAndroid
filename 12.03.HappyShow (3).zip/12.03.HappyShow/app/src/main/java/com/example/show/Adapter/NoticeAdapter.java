package com.example.show.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.example.show.DTO.NoticeDTO;
import com.example.show.R;

import java.util.ArrayList;
import java.util.HashMap;


public class NoticeAdapter extends BaseExpandableListAdapter {
    private Context context;
    private ArrayList<NoticeDTO> dtos;
    private ArrayList<String> arrayGroup;
    private HashMap<String, ArrayList<String> > arrayChild;

    private LayoutInflater inflater;

    private static final String TAG = "NoticeAdapter :";

    public NoticeAdapter(Context context, ArrayList<NoticeDTO> dtos, ArrayList<String> arrayGroup,
                         HashMap<String, ArrayList<String>> arrayChild) {
        this.context = context;
        this.dtos = dtos;
        this.arrayGroup = arrayGroup;
        this.arrayChild = arrayChild;

        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getGroupCount() {
        return arrayGroup.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return arrayChild.get(arrayGroup.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return  arrayGroup.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return arrayChild.get(arrayGroup.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }


    // 타이틀 그룹을 보여주는 것 같음.
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String groupName = arrayGroup.get(groupPosition);
        View v = convertView;

        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.notice_list_item, null);

        }
        TextView textGroup = v.findViewById(R.id.notice_title);
        textGroup.setText(groupName);

        return v;


       /* Log.d(TAG, "getGroupView:  " + groupPosition);
        noticeViewHolder noticeViewHolder;

        if(convertView == null) {
            convertView = inflater.inflate(R.layout.notice_list_item, parent, false);

            // 화면을 새로 만든다.
            noticeViewHolder = new noticeViewHolder();

            noticeViewHolder.notice_title = convertView.findViewById(R.id.notice_title);

            convertView.setTag(noticeViewHolder);

        }else { // 캐시된 ㅠ가 있을 경우 이미 생성된 뷰 홀더 재 사용
            noticeViewHolder = (NoticeAdapter.noticeViewHolder) convertView.getTag();


        }

        // 선택한 dto 데이터를 가져오기
        NoticeDTO dto = dtos.get(groupPosition);

        Log.d(TAG, "getGroupView: " + dto.getTitle());


        // 화면에 데이터 연결하기
        noticeViewHolder.notice_title.setText(dtos.get(groupPosition).getTitle());


        return convertView;*/
    }

    // 아래 하단 바 띄울 거 말하는 듯
    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        String childName = arrayChild.get(arrayGroup.get(groupPosition)).get(childPosition);
        View v = convertView;

        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.notice_list_item_tv, null);

        }
        TextView textChild = v.findViewById(R.id.notice_list_content);
        textChild.setText(childName);

        return v;


       /* Log.d(TAG, "getChildView: " +groupPosition +"childPosition: " +childPosition);
        noticeViewHolder noticeViewHolder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.notice_list_item_tv, parent, false);

            noticeViewHolder = new noticeViewHolder();

            noticeViewHolder.notice_list_content = convertView.findViewById(R.id.notice_list_content);

            convertView.setTag(noticeViewHolder);
        }else {
            noticeViewHolder = (NoticeAdapter.noticeViewHolder) convertView.getTag();
        }

        NoticeDTO dto = dtos.get(groupPosition);

        Log.d(TAG, "getChildView: " +dto.getContent());

        // 화면에 데이터 연결하기

        noticeViewHolder.notice_list_content.setText(dtos.get(groupPosition).getContent());
        return convertView;*/
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }


    public class noticeViewHolder{
        public TextView notice_title, notice_list_content;
    }


}
