package com.example.show.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.show.ATask.MemberDeletSelect;
import com.example.show.DTO.MemberDTO;
import com.example.show.R;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.MemberViewHolder> {

    private static final String TAG = "Member:MemberAdatper";

    // member조회 액티비티에서 넘겨 받는것
    Context ad_member_Context;
    ArrayList<MemberDTO> ad_member_arrayList;


   // 화면을 붙이기 위한 객체 생성
    LayoutInflater ad_member_inflater;
    AlertDialog dialog;
    // 생성자로 메인에게 넘겨 받는다


    public MemberAdapter(Context ad_member_Context, ArrayList<MemberDTO> ad_member_arrayList) {
        this.ad_member_Context = ad_member_Context;
        this.ad_member_arrayList = ad_member_arrayList;

        this.ad_member_inflater = (LayoutInflater) ad_member_Context.getSystemService(ad_member_Context.LAYOUT_INFLATER_SERVICE);

    }






    public void deleteMemberDTO(int position) {

        ad_member_arrayList.remove(position);


    }





    // 화면을 인플레이트 시킨다 : 어떤 xml을 사용할 것인지 정한다.
    @NonNull
    @Override
    public MemberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = ad_member_inflater.inflate(R.layout.admin_member_view,parent,false);
        return new MemberViewHolder(itemView);
    }





    // 인플레이트 시킨 화면에 데이터 세팅
    @Override
    public void onBindViewHolder(@NonNull MemberViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Log.d(TAG, "MemberAdapter:onBindViewHolder: " +position);

        MemberDTO ad_member_dto =ad_member_arrayList.get(position);
        holder.set_ad_Member(ad_member_dto);

        holder.admin_parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MemberDTO dto = ad_member_arrayList.get(position);
                // 여기서 행복하게 삭제이벤트를 걸어줍니다.
                popUpMember(ad_member_arrayList.get(position));
            }
        });


    }

    @Override
    public int getItemCount() {
        return ad_member_arrayList.size();
    }

    //3. xml 파일에서사용된 모든 변수를 adapter에서 클래스로 선언
    public class MemberViewHolder extends RecyclerView.ViewHolder{
        TextView admin_member_name, admin_member_nickname, admin_member_type;
        TextView admin_member_popup_name, admin_member_popup_nickname, admin_member_popup_type, admin_member_popup_address,admin_member_popup_joindate;
        ImageView admin_member_img, admin_member_popup_img;
        LinearLayout admin_parentLayout;




        public MemberViewHolder(@NonNull View itemView) {
            super(itemView);

            admin_parentLayout = itemView.findViewById(R.id.admin_parentLayout);
            admin_member_name= itemView.findViewById(R.id.admin_member_name);
            admin_member_type= itemView.findViewById(R.id.admin_member_type);
            admin_member_nickname= itemView.findViewById(R.id.admin_member_nickname);
            admin_member_img= itemView.findViewById(R.id.admin_member_img);
        }

        //데이터를 세팅 시키는 함수
        public void set_ad_Member(MemberDTO memberDTO) {
            admin_member_name.setText(memberDTO.getEmail());
            admin_member_type.setText(memberDTO.getType());
            admin_member_nickname.setText(memberDTO.getNickname());


            /*Glide.with(ad_member_Context).load(ad_member_arrayList.getI)*/
        }
    }

    private void popUpMember(MemberDTO dto) {
        LayoutInflater inflater = LayoutInflater.from(ad_member_Context);
        View view = inflater.inflate(R.layout.admin_member_popup, null);

        ImageView admin_member_popup_img = view.findViewById(R.id.admin_member_popup_img);
        TextView  admin_member_popup_name = view.findViewById(R.id.admin_member_popup_name);
        TextView  admin_member_popup_nickname = view.findViewById(R.id.admin_member_popup_nickname);
        TextView  admin_member_popup_type = view.findViewById(R.id.admin_member_popup_type);
        TextView  admin_member_popup_address = view.findViewById(R.id.admin_member_popup_address);
        TextView  admin_member_popup_joindate = view.findViewById(R.id.admin_member_popup_joindate);

        admin_member_popup_img.setImageResource(R.drawable.dream01);
        admin_member_popup_name.setText(dto.getName());
        admin_member_popup_nickname.setText(dto.getNickname());
        admin_member_popup_type.setText(dto.getType());
        admin_member_popup_address.setText(dto.getAddress());



        AlertDialog.Builder builder = new AlertDialog.Builder(ad_member_Context);
        builder.setTitle(dto.getName()+"님의 정보").setView(view);


        builder.setNegativeButton("삭제", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(dialog != null){
                   String email= dto.getEmail();
                    if(email != null){
                        MemberDeletSelect memberDeletSelect = new MemberDeletSelect(email);

                        try {
                            memberDeletSelect.execute().get();
                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        deleteMemberDTO(which);
                    }else {

                        Toast.makeText(view.getContext(), "존재하지 않는 회원입니다.", Toast.LENGTH_SHORT).show();

                    }

                }
            }
        });


        builder.setPositiveButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(dialog != null){
                    dialog.dismiss();
                }
            }
        });


        dialog = builder.create();
        dialog.show();

    }
}
