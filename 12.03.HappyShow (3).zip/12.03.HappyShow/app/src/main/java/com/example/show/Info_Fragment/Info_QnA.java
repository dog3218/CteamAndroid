package com.example.show.Info_Fragment;

import static com.example.show.Common.CommonMethod.BoarDDTO;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.InformationActivity;
import com.example.show.R;

public class Info_QnA extends Fragment {

    InformationActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.info_qna_fragment, container, false);

        activity = (InformationActivity) getActivity();
        TextView tv_info_qna = rootView.findViewById(R.id.tv_info_qa);

        tv_info_qna.setText("홈페이지 : " + BoarDDTO.getHomepageurl() + "\n" + "문의 : " + BoarDDTO.getPhonenumber());

        return rootView;

    }
}
