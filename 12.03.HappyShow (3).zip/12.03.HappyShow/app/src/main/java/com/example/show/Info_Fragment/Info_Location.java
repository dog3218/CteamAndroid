package com.example.show.Info_Fragment;

import static com.example.show.Common.CommonMethod.BoarDDTO;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.InformationActivity;
import com.example.show.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class Info_Location extends Fragment implements OnMapReadyCallback {
    private MapView info_map = null;
    InformationActivity activity;

    Double latitude;

    Double longitude;

    Context context;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.info_location_fragment, container, false);
        TextView tv_info_location = rootView.findViewById(R.id.tv_info_location);

//---------------------------
        final Geocoder geocoder = new Geocoder(getContext());
        String value = BoarDDTO.getRdnmadr();
        List<Address> list = null;
        String str = value;


        if (BoarDDTO.getRdnmadr() != null) {
            tv_info_location.setText(BoarDDTO.getRdnmadr());
        } else {
            tv_info_location.setText(BoarDDTO.getLnmadr());
        }


        if (latitude == null) {

            try {
                list = geocoder.getFromLocationName(str, 10);
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (list != null) {
                if (list.size() == 0) {
                    Toast.makeText(getContext(), "해당되는 주소 x", Toast.LENGTH_SHORT).show();
                } else {
                    Address addr = list.get(0);
                    latitude = Double.valueOf(addr.getLatitude());
                    longitude = Double.valueOf(addr.getLongitude());
                }
            }
//--------------------
        } else {
            latitude = Double.valueOf(BoarDDTO.getLatitude());
            longitude = Double.valueOf(BoarDDTO.getLongitude());
        }

        info_map = rootView.findViewById(R.id.info_map);
        info_map.getMapAsync(this);

        activity = (InformationActivity) getActivity();


        return rootView;
    }


/*
    private Location findGeoPoint(Context mContext, String address) {
        Location loc = new Location("");
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        List<Address> addresses = null;

        try {
            addresses = geocoder.getFromLocationName(address, 5);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(addresses != null) {
            for(int i = 0; i < addresses.size(); i++) {
                Address lati = addresses.get(i);
                double lat =  Double.valueOf(lati.getLatitude());
                double lon =  Double.valueOf(lati.getLongitude());

                loc.setLatitude(lat);
                loc.setLongitude(lon);
            }
        }else {
            Address addr = addresses.get(0);
        }
        return loc;
    }
*/

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //실행 함수
        if (info_map != null) {
            info_map.onCreate(savedInstanceState);
        }
    }

    //지도를 불러오는 메소드
    @Override
    public void onStart() {
        super.onStart();
        info_map.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        info_map.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        info_map.onResume();
    }

    //info_map 설정
    @Override
    public void onMapReady(GoogleMap googleMap) {


        //위도, 경도
        LatLng location = new LatLng(latitude, longitude);

        //옵션
        MarkerOptions marker = new MarkerOptions();
        marker.position(location);
        marker.title(BoarDDTO.getOpar());
        marker.snippet(BoarDDTO.getLnmadr());

        //맵에 마커 표시, 인포윈도우 표시
        googleMap.addMarker(marker).showInfoWindow();
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(14));


    }
/*
    public GeoPoint getLocationFromAddress(String strAddress) {

        Geocoder coder = new Geocoder(getContext());
        List<Address> address;
        GeoPoint p1 = null;

        try {
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new GeoPoint((double) (location.getLatitude() ),
                    (double) (location.getLongitude() ));


        } catch (IOException e) {
            e.printStackTrace();
        }
        return p1;
    }*/
}