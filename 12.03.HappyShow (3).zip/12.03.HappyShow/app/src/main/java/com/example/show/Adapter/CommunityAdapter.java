package com.example.show.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.show.DTO.CommunityDTO;
import com.example.show.R;

import java.util.ArrayList;

public class CommunityAdapter extends BaseAdapter {

    private static final String TAG = "CommunityAdapter:";

    Context context;
    ArrayList<CommunityDTO> dtos;

    // 화면을 붙이기 위한 화면 생성
    LayoutInflater inflater;


    public CommunityAdapter(Context context, ArrayList<CommunityDTO> dtos) {
        this.context = context;
        this.dtos = dtos;

        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public Object getItem(int i) {
        return dtos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        CommunityFragmentViewHolder communityFragmentViewHolder;

        // 캐시된 뷰가 없을 경우 새로 뷰 홀더를 생성하고 있으면 그 뷰를 재활용 한다.
        if(convertView == null) {
            convertView = inflater.inflate(R.layout.community_list_fragment, parent, false);
            // 화면을 새로 만든다.
            communityFragmentViewHolder = new CommunityFragmentViewHolder();

            //붙힌 화면과 아래에 생성한 뷰 홀더를 연결
            communityFragmentViewHolder.community_list_title = convertView.findViewById(R.id.community_list_title);
            communityFragmentViewHolder.community_list_writer = convertView.findViewById(R.id.community_list_writer);
            communityFragmentViewHolder.community_list_readcnt = convertView.findViewById(R.id.community_list_readcnt);

            convertView.setTag(communityFragmentViewHolder);

        }else {     // 캐시된 뷰가 있을 경우 이미 생성된 뷰 홀더 재 사용
            communityFragmentViewHolder = (CommunityFragmentViewHolder) convertView.getTag();
        }

        CommunityDTO dto = dtos.get(position);
        Log.d(TAG, "getView: " +dto.getTitle());

        communityFragmentViewHolder.community_list_title.setText(dtos.get(position).getTitle());
        communityFragmentViewHolder.community_list_writer.setText(dtos.get(position).getWriter());
        communityFragmentViewHolder.community_list_readcnt.setText(String.valueOf(dtos.get(position).getReadcnt()));
        return convertView;
    }

    //붙일 아이템들 다 선언해주기
    public class CommunityFragmentViewHolder {
        public TextView community_list_title, community_list_writer, community_list_readcnt;


    }

}
