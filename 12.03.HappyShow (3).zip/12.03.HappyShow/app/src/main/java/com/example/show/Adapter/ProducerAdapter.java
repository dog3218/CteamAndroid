package com.example.show.Adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.show.Certificate_Director_Activity;
import com.example.show.DTO.Producer_CheckDTO;
import com.example.show.R;

import java.util.ArrayList;

public class ProducerAdapter extends BaseAdapter {
    private static final String TAG = "main:BoardAdapter";
    //메인에서 넘겨받을 것 -> 생성자를 만든다.
    Certificate_Director_Activity activity;
    ArrayList<Producer_CheckDTO> dtos;

    //화면을 붙이기 위한 화면생성
    LayoutInflater  inflater;

    public ProducerAdapter(Certificate_Director_Activity activity, ArrayList<Producer_CheckDTO> dtos) {
        this.activity = activity;
        this.dtos = dtos;

        this.inflater = (LayoutInflater) activity.getSystemService(activity.LAYOUT_INFLATER_SERVICE);
    }



    //=============================================================//
    //메소드를 만들 때는 무조건 여기에 생성한다(adapter)
    //하나의 dto 추가하기 (SingerDTO)
    public void addDto(Producer_CheckDTO dto) {
        dtos.add(dto);
    }

    //dtos의 모든 내용 지우기
    public void removeDtos(){
        dtos.clear();
    }
    //=============================================================//


    //dtos에 저장된 dto 개수
    @Override
    public int getCount() {
        return dtos.size();
    }

    //dtos의 특정위치에 있는 dto 가져오기(SingerDTO)
    @Override
    public Object getItem(int position) {
        return dtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    //☆가장 중요☆ : 화면을 생성하고 특정 뷰에 대한 클릭이벤트를 만들 수 있다.
    //만약 화면 5개를 생성한다면 getView가 5번 실행된다.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "getView: " + position);

        ShowViewHolder viewHolder;

        //캐시된 뷰가 없을 경우 새로 뷰홀더를 생성하고 있으면 그 뷰를 재활용한다.
        if (convertView == null) {
            //화면을 새로 만든다
            convertView = inflater.inflate(R.layout.activity_certificate_director, parent, false);

            viewHolder = new ShowViewHolder();
            //붙힌 화면과 아래에 생성한 뷰홀더를 연결한다.
            viewHolder.iv_certi1 = convertView.findViewById(R.id.iv_certi1);
            viewHolder.iv_certi2 = convertView.findViewById(R.id.iv_certi2);
            viewHolder.iv_certi3 = convertView.findViewById(R.id.iv_certi3);

            convertView.setTag(viewHolder);
        }else { //캐시된 뷰가 있을 경우 이미 생성된 뷰홀더를 사용한다.
            viewHolder = (ShowViewHolder) convertView.getTag();
        }

        //선택한 dto 데이터를 가져오기
        Producer_CheckDTO dto = dtos.get(position);



        Log.d(TAG, "getView: " + dto.getNo());
        //int resImg = dto.getNo();

        //화면에 데이터를 연결하기
        // viewHolder.slidePoster.setImageResource(resImg);

        Glide.with(activity).load(dto.getFilepath1()).into(viewHolder.iv_certi1);
        Glide.with(activity).load(dto.getFilepath2()).into(viewHolder.iv_certi2);
        Glide.with(activity).load(dto.getFilepath3()).into(viewHolder.iv_certi3);

        return convertView;
    }

    /*3.xml 파일에서 사용된 모든 변수를 Adapter에서 클래스로 선언한다*/
    public class ShowViewHolder{
        public ImageView iv_certi1, iv_certi2, iv_certi3;
    }
}
