package com.example.show;

import static com.example.show.Common.CommonMethod.isNetworkConnected;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ExpandableListView;
import android.widget.Toast;

import com.example.show.ATask.NoticeSelect;
import com.example.show.Adapter.NoticeAdapter;
import com.example.show.DTO.NoticeDTO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class NoticeActivity extends AppCompatActivity {

    private  ArrayList<NoticeDTO> dtos;
    private ArrayList<String> arrayGroup;
    private HashMap<String, ArrayList<String> > arrayChild;
    ExpandableListView notice_list;
    NoticeAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);

        arrayGroup = new ArrayList<String>();
        arrayChild = new HashMap<String, ArrayList<String>>();

        // 리스트 생성
        dtos = new ArrayList<>();
        notice_list = findViewById(R.id.notice_list);


        adapter = new NoticeAdapter(NoticeActivity.this, dtos, arrayGroup, arrayChild);
        notice_list.setAdapter(adapter);

        if(isNetworkConnected(NoticeActivity.this) == true){
            NoticeSelect noticeSelect = new NoticeSelect(dtos,adapter , arrayGroup, arrayChild);

            try {
                noticeSelect.execute().get();
            }catch (ExecutionException e){
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(NoticeActivity.this, "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }



    }
}