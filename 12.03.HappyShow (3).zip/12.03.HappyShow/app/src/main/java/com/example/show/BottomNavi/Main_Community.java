package com.example.show.BottomNavi;

import static com.example.show.Common.CommonMethod.isNetworkConnected;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.ATask.BoardSelect;
import com.example.show.ATask.CommunityAllSelect;
import com.example.show.Adapter.CommunityAdapter;
import com.example.show.Com_List_Activity;
import com.example.show.DTO.CommunityDTO;
import com.example.show.MainActivity;
import com.example.show.R;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Main_Community extends Fragment {
    Button main_com_btn_review, main_com_btn_with, main_com_btn_Qna;

    Context context;

    // database에서 불러올 adapter, dto, type 선언해준다.
    ArrayList<CommunityDTO> dtos_show, dtos_with, dtos_qna;
    String subject;
    MainActivity activity;
    CommunityAdapter communityAdapter_show, communityAdapter_with, communityAdapter_qna;

    ListView main_com_review_list, main_com_with_list, main_com_QnA_list;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity)getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_community, container, false);

        // 리스트 생성
        dtos_show = new ArrayList<>();
        dtos_with = new ArrayList<>();
        dtos_qna = new ArrayList<>();
        main_com_review_list = rootView.findViewById(R.id.main_com_review_list);
        main_com_with_list = rootView.findViewById(R.id.main_com_with_list);
        main_com_QnA_list = rootView.findViewById(R.id.main_com_QnA_list);

        communityAdapter_show = new CommunityAdapter(getActivity(),dtos_show);
        communityAdapter_with = new CommunityAdapter(getActivity(),dtos_with);
        communityAdapter_qna = new CommunityAdapter(getActivity(),dtos_qna);



        // 공연 후기  ---------------------------------------
        main_com_review_list.setAdapter(communityAdapter_show);
        subject = "공연후기";

        if(isNetworkConnected(getContext()) == true){
            //AsyncTask 생성
            CommunityAllSelect communityAllSelect = new CommunityAllSelect(dtos_show, communityAdapter_show, subject);

            try {
                communityAllSelect.execute().get();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }

        main_com_review_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        // 동행 구해요 -----------------------------------------

        main_com_with_list.setAdapter(communityAdapter_with);
        subject = "동행구해요";
        if(isNetworkConnected(getContext()) == true){
            //AsyncTask 생성
            CommunityAllSelect communityAllSelect = new CommunityAllSelect(dtos_with, communityAdapter_with, subject);

            try {
                communityAllSelect.execute().get();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }

        main_com_with_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

        // qna -----------------------------------------

        main_com_QnA_list.setAdapter(communityAdapter_qna);
        subject = "자유";
        if(isNetworkConnected(getContext()) == true){
            //AsyncTask 생성
            CommunityAllSelect communityAllSelect = new CommunityAllSelect(dtos_qna, communityAdapter_qna, subject);

            try {
                communityAllSelect.execute().get();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }

        main_com_QnA_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });







        rootView.findViewById(R.id.main_com_btn_review).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "공연후기";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_review_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "공연후기";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        //44, 52번째 줄 엑티비티 생성요망
//-----------------------------------------------------------------------------------------------------
        rootView.findViewById(R.id.main_com_btn_with).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "동행구해요";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_with_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "동행구해요";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_btn_QnA).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "자유";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);


            }
        });

        rootView.findViewById(R.id.main_com_QnA_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "자유";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });
//-----------------------------------------------------------------------------------------------------
        return rootView;
    }

}