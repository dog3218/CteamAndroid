package com.example.show.DTO;

import java.io.Serializable;

public class NoticeDTO implements Serializable {
    private String title, content, writedate, writer;
    private int id ,importance, readcnt;

    public NoticeDTO(String title, String content, String writedate, String writer, int importance, int readcnt) {
        this.title = title;
        this.content = content;
        this.writedate = writedate;
        this.writer = writer;
        this.importance = importance;
        this.readcnt = readcnt;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getWritedate() {
        return writedate;
    }

    public void setWritedate(String writedate) {
        this.writedate = writedate;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImportance() {
        return importance;
    }

    public void setImportance(int importance) {
        this.importance = importance;
    }

    public int getReadcnt() {
        return readcnt;
    }

    public void setReadcnt(int readcnt) {
        this.readcnt = readcnt;
    }
}
