package com.example.show;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.example.show.Common.CommonMethod.loginDTO;

import com.example.show.ATask.CommuInsert;
import com.example.show.ATask.JoinInsert;

import java.util.concurrent.ExecutionException;


public class Com_Write_Activity extends AppCompatActivity {
    private static final String TAG = "Com_Write_Activity";
    EditText etTitle, etContent;
    Button btnUpLoad;
    int state = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_com_write);


        etTitle = findViewById(R.id.etTitle);
        etContent = findViewById(R.id.etContent);
        btnUpLoad = findViewById(R.id.btnUpLoad);

        //게시글 업로드
        btnUpLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = loginDTO.getEmail();
                String title = etTitle.getText().toString();
                String content = etContent.getText().toString();
                String subject = "with";
                //이 정보를 비동기 Task로 넘겨 서버에게 전달함
                CommuInsert commuInsert = new CommuInsert(email, title, content, subject);
                try {
                    state = (Integer) commuInsert.execute().get();
                    Log.d(TAG, "onClick: state" + state);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finish();
            }
        });
    }
}