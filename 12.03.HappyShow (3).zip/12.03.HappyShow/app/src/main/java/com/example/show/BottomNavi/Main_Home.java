package com.example.show.BottomNavi;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.show.Adapter.ImageSliderAdapter;
import com.example.show.MainActivity;
import com.example.show.Main_Home_Fragment.Main_Home_All;
import com.example.show.Main_Home_Fragment.Main_Home_Concert;
import com.example.show.Main_Home_Fragment.Main_Home_Exhibition;
import com.example.show.Main_Home_Fragment.Main_Home_Musical;
import com.example.show.Main_Home_Fragment.Main_Home_Opera;
import com.example.show.Main_Home_Fragment.Main_Home_Play;
import com.example.show.R;
import com.google.android.material.tabs.TabLayout;

public class Main_Home extends Fragment {

    Main_Home_Opera main_home_opera;
    Main_Home_All main_home_all;
    Main_Home_Concert main_home_concert;
    Main_Home_Musical main_home_musical;
    Main_Home_Play main_home_play;
    Main_Home_Exhibition main_home_exhibition;
    Fragment selectFragment= null;

    TabLayout main_home_tabs;
    FrameLayout main_home_contain;

    MainActivity activity;


    GridView gridView;
    ConstraintLayout slide_layout;


    //11.26============================================================================================
    Button btn_Top;
//11.26============================================================================================


    private ViewPager2 sliderViewPager;
    private LinearLayout layoutIndicator;
    private String[] images = new String[] {
            "http://192.168.0.10:80/app/resources/show_cultwo.png",
            "https://cdn.pixabay.com/photo/2020/11/04/15/29/coffee-beans-5712780_1280.jpg",
            "https://cdn.pixabay.com/photo/2020/03/08/21/41/landscape-4913841_1280.jpg",
            "https://cdn.pixabay.com/photo/2020/09/02/18/03/girl-5539094_1280.jpg",
            "https://cdn.pixabay.com/photo/2014/03/03/16/15/mosque-279015_1280.jpg"
    };



    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity= (MainActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_home, container, false);

        main_home_opera = new Main_Home_Opera();
        main_home_concert = new Main_Home_Concert();
        main_home_all = new Main_Home_All();
        main_home_exhibition = new Main_Home_Exhibition();
        main_home_musical = new Main_Home_Musical();
        main_home_play = new Main_Home_Play();

        gridView = rootView.findViewById(R.id.main_home_all_gridView);
//11.27=============================================================================================
        slide_layout = rootView.findViewById(R.id.slide_layout);
        sliderViewPager = rootView.findViewById(R.id.sliderViewPager);
        layoutIndicator = rootView.findViewById(R.id.layoutIndicators);

        sliderViewPager.setOffscreenPageLimit(1);

        sliderViewPager.setAdapter(new ImageSliderAdapter(activity, images));

        sliderViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                setCurrentIndicator(position);
            }
        });

        setupIndicators(images.length);
//11.27=============================================================================================

        btn_Top = rootView.findViewById(R.id.btn_Top);

        btn_Top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                main_home_all.positionTop(0);
            }       /////이거 11.27추가
        });

//11.26============================================================================================

        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();

        main_home_tabs = rootView.findViewById(R.id.main_home_tabs);
        main_home_tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_all.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_musical).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_musical.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_opera).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_opera.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_play).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_play.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_exhibition).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_exhibition.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;
                    case 5:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_concert).commit();
                        //11.26============================================================================================
                        btn_Top.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                main_home_concert.positionTop(0);
                            }
                        });
                        //11.26============================================================================================
                        break;


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;
    }
    //11.27=============================================================================================
    public void topImgDisappear(int state){
        if(state == 1){
            slide_layout.setVisibility(View.GONE);
//            main_home_all.set
        }else if(state == 0){
            slide_layout.setVisibility(View.VISIBLE);
        }

    }
//11.27=============================================================================================
    //11.26============================================================================================



//11.26============================================================================================

    private void setupIndicators(int count) {
        ImageView[] indicators = new ImageView[count];
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        params.setMargins(16, 8, 16, 8);

        for (int i = 0; i < indicators.length; i++) {
            indicators[i] = new ImageView(activity);
            indicators[i].setImageDrawable(ContextCompat.getDrawable(activity,
                    R.drawable.bg_indicator_inactive));
            indicators[i].setLayoutParams(params);
            layoutIndicator.addView(indicators[i]);
        }
        setCurrentIndicator(0);
    }

    private void setCurrentIndicator(int position) {
        int childCount = layoutIndicator.getChildCount();
        for (int i = 0; i < childCount; i++) {
            ImageView imageView = (ImageView) layoutIndicator.getChildAt(i);
            if (i == position) {
                imageView.setImageDrawable(ContextCompat.getDrawable(
                        activity,
                        R.drawable.bg_indicator_active
                ));
            } else {
                imageView.setImageDrawable(ContextCompat.getDrawable(
                        activity,
                        R.drawable.bg_indicator_inactive
                ));
            }
        }
    }
}
