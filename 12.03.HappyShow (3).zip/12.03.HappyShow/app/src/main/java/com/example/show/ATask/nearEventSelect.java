package com.example.show.ATask;

import static com.example.show.Common.CommonMethod.ipConfig;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;

import com.example.show.DTO.BoardDTO;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class nearEventSelect extends AsyncTask<ArrayList<BoardDTO>, Void, Void> {
    private static final String TAG = "nearEventSelect";


    ArrayList<BoardDTO> list;
    double currentLatitude, currentlangitude;

    public nearEventSelect(ArrayList<BoardDTO> list, double currentLatitude, double currentlangitude) {
        this.list = list;
        this.currentLatitude = currentLatitude;
        this.currentlangitude = currentlangitude;
    }

    //Async반드시 선언해야 할 것들 : 무조건 해야함... 복붙.
    HttpClient httpClient; //클라이언트 객체
    HttpPost httpPost;  //클라이언트에 붙힐 본문
    HttpResponse httpResponse;  //서버에서의 응답받는 곳
    HttpEntity httpEntity;  //응답내용


    @Override
    protected Void doInBackground(ArrayList<BoardDTO>... arrayLists) {
        try {

            //MultipartEntityBuilder 생성 : 무조건 해야 함 .복붙.
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.setCharset(Charset.forName("UTF-8"));

            //전송
            //전송 url : 수정해야 할 부분
            String postURL = ipConfig + "nearLocationSelect_app";

            builder.addTextBody("currentLangitude",  currentlangitude+ "", ContentType.create("Multipart/related", "UTF-8"));
            builder.addTextBody("currentLatitude",  currentLatitude+ "", ContentType.create("Multipart/related", "UTF-8"));

            //그대로 사용 복붙
            InputStream inputStream = null;
            httpClient = AndroidHttpClient.newInstance("Android");
            httpPost = new HttpPost(postURL);
            httpPost.setEntity(builder.build());
            httpResponse = httpClient.execute(httpPost); //보내고 응답받는 부분
            httpEntity = httpResponse.getEntity(); //응답내용을 저장
            inputStream = httpEntity.getContent(); //응답내용을 inputStream에 넣는다

            //데이터가 ArrayList<DTO> 형태일 때
            readJsonStream(inputStream);
            inputStream.close();

        } catch (Exception e) {
            e.getMessage();
        } finally {
            if (httpEntity != null) {
                httpEntity = null;
            }
            if (httpResponse != null) {
                httpResponse = null;
            }
            if (httpPost != null) {
                httpPost = null;
            }
            if (httpClient != null) {
                httpClient = null;
            }
        }

        return null;

    }


    public void readJsonStream(InputStream inputStream) throws IOException {
        JsonReader reader = new JsonReader(new InputStreamReader(inputStream, "UTF-8"));
        try {
            reader.beginArray();
            while (reader.hasNext()) {
                list.add(readMessage(reader));
            }
            reader.endArray();
            Log.d(TAG, "readJsonStream: size => " + list.size());
        } finally {
            reader.close();
        }
    }

    public BoardDTO readMessage(JsonReader reader) throws IOException {
        String eventnm = "", opar = "", eventco = "", eventstartdate = "", eventenddate = "", eventstarttime = "", eventendtime = "", chrgeinfo = "", mnnst = "", auspcinstt = "",
                phonenumber = "", suprtinstt = "", seatnumber = "", admfee = "", entncage = "", dscntinfo = "", atpn = "", homepageurl = "", advantkinfo = "", prkplceyn = "", rdnmadr = "",
                lnmadr = "", latitude = "", longitude = "", referencedate = "", filepath = "", writer = "", on_offline = "";
        int no = 0, readcnt=0;
        reader.beginObject();

        while (reader.hasNext()) {
            String readStr = reader.nextName();
            if (readStr.equals("eventnm")) {
                eventnm = reader.nextString();
            } else if (readStr.equals("opar")) {
                opar = reader.nextString();
            } else if (readStr.equals("eventco")) {
                eventco = reader.nextString();
            } else if (readStr.equals("eventstartdate")) {
                eventstartdate = reader.nextString();
            } else if (readStr.equals("eventenddate")) {
                eventenddate = reader.nextString();
            } else if (readStr.equals("eventendtime")) {
                eventendtime = reader.nextString();
            } else if (readStr.equals("eventstarttime")) {
                eventstarttime = reader.nextString();
            } else if (readStr.equals("chrgeinfo")) {
                chrgeinfo = reader.nextString();
            } else if (readStr.equals("mnnst")) {
                mnnst = reader.nextString();
            } else if (readStr.equals("auspcinstt")) {
                auspcinstt = reader.nextString();
            } else if (readStr.equals("phonenumber")) {
                phonenumber = reader.nextString();
            } else if (readStr.equals("suprtinstt")) {
                suprtinstt = reader.nextString();
            } else if (readStr.equals("seatnumber")) {
                seatnumber = reader.nextString();
            } else if (readStr.equals("admfee")) {
                admfee = reader.nextString();
            } else if (readStr.equals("entncage")) {
                entncage = reader.nextString();
            } else if (readStr.equals("dscntinfo")) {
                dscntinfo = reader.nextString();
            } else if (readStr.equals("atpn")) {
                atpn = reader.nextString();
            } else if (readStr.equals("homepageurl")) {
                homepageurl = reader.nextString();
            } else if (readStr.equals("advantkinfo")) {
                advantkinfo = reader.nextString();
            } else if (readStr.equals("prkplceyn")) {
                prkplceyn = reader.nextString();
            } else if (readStr.equals("rdnmadr")) {
                rdnmadr = reader.nextString();
            } else if (readStr.equals("lnmadr")) {
                lnmadr = reader.nextString();
            } else if (readStr.equals("latitude")) {
                latitude = reader.nextString();
            } else if (readStr.equals("longitude")) {
                longitude = reader.nextString();
            } else if (readStr.equals("referencedate")) {
                referencedate = reader.nextString();
            } else if (readStr.equals("filepath")) {
                filepath = ipConfig + "resources/" + reader.nextString();
                Log.d(TAG, "readMessage: filepath => " + filepath);
            } else if (readStr.equals("writer")) {
                writer = reader.nextString();
            } else if (readStr.equals("on_offline")) {
                on_offline = reader.nextString();
            } else if (readStr.equals("no")) {
                no = Integer.parseInt(reader.nextString());
            } else if (readStr.equals("readcnt")) {
                readcnt = Integer.parseInt(reader.nextString());
            } else {
                reader.skipValue();
            }
        }
        reader.endObject();
        return new BoardDTO(eventnm, opar, eventco, eventstartdate, eventenddate, eventstarttime, eventendtime, chrgeinfo, mnnst, auspcinstt, phonenumber,
                suprtinstt, seatnumber, admfee, entncage, dscntinfo, atpn, homepageurl, advantkinfo, prkplceyn, rdnmadr, lnmadr, latitude, longitude, referencedate,
                filepath, writer, on_offline, no, readcnt);
    }
}