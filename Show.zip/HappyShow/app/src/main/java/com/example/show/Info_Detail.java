package com.example.show;

import static com.example.show.Common.CommonMethod.BoarDDTO;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Info_Detail extends Fragment {

    TextView tv_info_detail;


    InformationActivity activity;
    String type;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.info_detail_fragment, container, false);

        activity = (InformationActivity) getActivity();
        TextView tv_info_detail = rootView.findViewById(R.id.tv_info_detail);

        tv_info_detail.setText("공연 일정 : " + BoarDDTO.getEventstartdate() + " ~ " + BoarDDTO.getEventenddate() + "\n" +
                "공연 시간 : "+BoarDDTO.getEventstarttime() + " ~ " + BoarDDTO.getEventendtime() + "\n" + "가격 정보 : " + BoarDDTO.getAdmfee()
                + "\n" + "주관 기관 : " + BoarDDTO.getMnnst() + "\n" + "주최 기관 : " + BoarDDTO.getAuspcinstt() + "\n" + "후원 기관 : " + BoarDDTO.getSuprtinstt()+
                "\n" + "입장 연령 : " + BoarDDTO.getEntncage() + "\n" + "주차장 : " + BoarDDTO.getPrkplceyn() + "\n" + "유의 사항 : " + BoarDDTO.getAtpn()
                + "\n" + "티켓팅 : " + BoarDDTO.getAdvantkinfo());



        return rootView;

    }
}
