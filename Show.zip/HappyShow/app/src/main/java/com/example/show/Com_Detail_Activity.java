package com.example.show;

import static com.example.show.Common.CommonMethod.communityDTO;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.show.DTO.CommunityDTO;

public class Com_Detail_Activity extends AppCompatActivity {

    TextView com_detail_title, com_detail_nickname, com_detail_writedate, com_detail_readcnt, com_detail_content;
    ImageView com_detail_filename1, com_detail_filename2, com_detail_filename3;

    String file1, file2, file3 = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_com_detail);

        // list 에서 담겨온 dto를 여기서 가져온다.
        Intent intent = getIntent();
        communityDTO = (CommunityDTO) intent.getSerializableExtra("dto");
        String email = intent.getStringExtra("email");
        String nickname = intent.getStringExtra("nickname");

        // xml에 있는 것들 모두 선언함
        com_detail_title = findViewById(R.id.com_detail_title);
        com_detail_nickname = findViewById(R.id.com_detail_nickname);
        com_detail_writedate = findViewById(R.id.com_detail_writedate);
        com_detail_readcnt = findViewById(R.id.com_detail_readcnt);
        com_detail_content = findViewById(R.id.com_detail_content);

        com_detail_filename1 = findViewById(R.id.com_detail_filename1);
        com_detail_filename2 = findViewById(R.id.com_detail_filename2);
        com_detail_filename3 = findViewById(R.id.com_detail_filename3);

        // dto에 담긴 정보들을 담기
        com_detail_title.setText(communityDTO.getTitle());
        com_detail_nickname.setText(nickname);
        com_detail_writedate.setText(communityDTO.getWritedate());
        com_detail_content.setText(communityDTO.getContent());
        com_detail_readcnt.setText(String.valueOf(communityDTO.getReadcnt()));


        /*if (communityDTO.getFilepath1() == "") {
            com_detail_filename1.setVisibility(View.GONE);
        }else {
            com_detail_filename1.setVisibility(View.VISIBLE);
            com
        }
        else if (communityDTO.getFilepath2() == ""){
            com_detail_filename2.setVisibility(View.GONE);
        }else if(communityDTO.getFilepath3() ==""){
            com_detail_filename3.setVisibility(View.GONE);
        }*/



 /*       com_detail_filename1.setImageResource(Integer.valueOf(communityDTO.getFilepath1()));
        com_detail_filename2.setImageResource(Integer.valueOf(communityDTO.getFilepath2()));
        com_detail_filename3.setImageResource(Integer.valueOf(communityDTO.getFilepath3()));*/

       /* file1= communityDTO.getFilepath1();
        file2= communityDTO.getFilepath2();
        file3= communityDTO.getFilepath3();

*/

    }
}