package com.example.show;

import static com.example.show.Common.CommonMethod.isNetworkConnected;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.ATask.BoardSelect;
import com.example.show.DTO.BoardDTO;
import com.example.show.DTO.Main_Recommend_DTO;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Main_Recommend_Fragment extends Fragment {

    ListView list_rank;
    Main_Recommend_ViewAdapter adapter;
    ArrayList<BoardDTO> dtos;
    Context main_recommend;
    String type = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_recommend_fragment_rank, container, false);

        //조회 선택(조회순, 좋아요순, 리뷰순)
        Spinner spinner_rank = rootView.findViewById(R.id.spinner_rank);
        ArrayAdapter rankAdaper = ArrayAdapter.createFromResource(getActivity(), R.array.rank, android.R.layout.simple_spinner_item);
        rankAdaper.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_rank.setAdapter(rankAdaper);
        spinner_rank.setSelection(0);
        String item = spinner_rank.getSelectedItem().toString();

        dtos = new ArrayList<>();
        main_recommend = getContext();

        list_rank = rootView.findViewById(R.id.list_rank);



        spinner_rank.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        type = "read";
                        adapter = new Main_Recommend_ViewAdapter(main_recommend, dtos);
                        dtos.clear();
                        adapter.notifyDataSetChanged();
                        list_rank.setAdapter(adapter);
                        if(isNetworkConnected(getContext()) == true){
                            //AsyncTask 생성
                            BoardSelect boardSelect = new BoardSelect(dtos, adapter, type);
                            try {
                                boardSelect.execute().get();
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }else {
                            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
                        }
                        break;


                    case 1:
                        type = "review";
                        dtos.clear();
                        adapter.notifyDataSetChanged();
                        adapter = new Main_Recommend_ViewAdapter(main_recommend, dtos);
                        list_rank.setAdapter(adapter);
                        if(isNetworkConnected(getContext()) == true){
                            //AsyncTask 생성
                            BoardSelect boardSelect = new BoardSelect(dtos, adapter, type);
                            try {
                                boardSelect.execute().get();
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }else {
                            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
                        }
                        break;

                    case 2:
                        type = "favorite";
                        dtos.clear();
                        adapter.notifyDataSetChanged();
                        adapter = new Main_Recommend_ViewAdapter(main_recommend, dtos);
                        list_rank.setAdapter(adapter);
                        if(isNetworkConnected(getContext()) == true){
                            //AsyncTask 생성
                            BoardSelect boardSelect = new BoardSelect(dtos, adapter, type);
                            try {
                                boardSelect.execute().get();
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }else {
                            Toast.makeText(getContext(), "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
                        }
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });





        //어댑터에 생성한 메소드 addDto를 이용하여 dtos에 데이터를 추가한다.


        list_rank.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                BoardDTO boardDTO = (BoardDTO) adapter.getItem(position);

                Intent intent = new Intent(getActivity(), InformationActivity.class);
                intent.putExtra("dto", boardDTO);
                startActivity(intent);

            }
        });

        return rootView;
    }



}