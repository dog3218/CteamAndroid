package com.example.show.ATask;

import static com.example.show.Common.CommonMethod.ipConfig;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;

import com.example.show.BoardAdapter;
import com.example.show.DTO.BoardDTO;
import com.example.show.Main_Recommend_ViewAdapter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;


public class BoardSelect extends AsyncTask<Void, Void, Void> {
    private static final String TAG = "BoardSelect";

    //생성자를 만들어서 데이터를 받는다
    //Context context;
    ArrayList<BoardDTO> dtos;
    BoardAdapter adapter;
    String type;
    Main_Recommend_ViewAdapter rAdapter;

    public BoardSelect(ArrayList<BoardDTO> dtos, BoardAdapter adapter, String type) {
        this.dtos = dtos;
        this.adapter = adapter;
        this.type = type;
    }

    public BoardSelect(ArrayList<BoardDTO> dtos, Main_Recommend_ViewAdapter rAdapter, String type) {
        this.dtos = dtos;
        this.rAdapter = rAdapter;
        this.type = type;
    }

    //Async반드시 선언해야 할 것들 : 무조건 해야함... 복붙.
    HttpClient httpClient; //클라이언트 객체
    HttpPost httpPost;  //클라이언트에 붙힐 본문
    HttpResponse httpResponse;  //서버에서의 응답받는 곳
    HttpEntity httpEntity;  //응답내용

    //실질적으로 일을하는 부분 : 접근 못함(textView, button)
    @Override
    protected Void doInBackground(Void... voids) {

        try {

            //MultipartEntityBuilder 생성 : 무조건 해야 함 .복붙.
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.setCharset(Charset.forName("UTF-8"));

            //전송
            //전송 url : 수정해야 할 부분
            String postURL = "";
            if (type.equals("all")) {
                postURL = ipConfig + "all";
            } else if (type.equals("musical")) {
                postURL = ipConfig + "musical";
            } else if (type.equals("opera")) {
                postURL = ipConfig + "opera";
            } else if (type.equals("play")) {
                postURL = ipConfig + "play";
            } else if (type.equals("exhibition")) {
                postURL = ipConfig + "exhibition";
            } else if (type.equals("concert")) {
                postURL = ipConfig + "concert";
            } else if (type.equals("read")) {
                postURL = ipConfig + "read";
            } else if (type.equals("review")) {
                postURL = ipConfig + "review";
            } else if (type.equals("favorite")) {
                postURL = ipConfig + "favorite";
            }
            //그대로 사용 복붙
            InputStream inputStream = null;
            httpClient = AndroidHttpClient.newInstance("Android");
            httpPost = new HttpPost(postURL);
            httpPost.setEntity(builder.build());
            httpResponse = httpClient.execute(httpPost); //보내고 응답받는 부분
            httpEntity = httpResponse.getEntity(); //응답내용을 저장
            inputStream = httpEntity.getContent(); //응답내용을 inputStream에 넣는다

            //데이터가 ArrayList<DTO> 형태일 때
            readJsonStream(inputStream);
            inputStream.close();

        }catch (Exception e){
            e.getMessage();
        }finally {
            if (httpEntity != null) {
                httpEntity = null;
            }
            if (httpResponse != null) {
                httpResponse = null;
            }
            if (httpPost != null) {
                httpPost = null;
            }
            if (httpClient != null) {
                httpClient = null;
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);

        Log.d(TAG, "onPostExecute: List Select Complete");

        //데이터가 새로 삽입되어서 하면 갱신을 해준다
        //adapter.notifyDataSetChanged();
    }

    public void readJsonStream(InputStream inputStream) throws IOException {
        JsonReader reader = new JsonReader(new InputStreamReader(inputStream, "UTF-8"));
        try {
            reader.beginArray();
            while (reader.hasNext()) {
                dtos.add(readMessage(reader));
            }
            reader.endArray();
            Log.d(TAG, "readJsonStream: size => " + dtos.size());
        } finally {
            reader.close();
        }
    }

    public BoardDTO readMessage(JsonReader reader) throws IOException {
        String eventnm = "", opar = "", eventco = "", eventstartdate = "", eventenddate = "", eventstarttime = "", eventendtime = "", chrgeinfo = "", mnnst = "", auspcinstt = "",
                phonenumber = "", suprtinstt = "", seatnumber = "", admfee = "", entncage = "", dscntinfo = "", atpn = "", homepageurl = "", advantkinfo = "", prkplceyn = "", rdnmadr = "",
                lnmadr = "", latitude = "", longitude = "", referencedate = "", filepath = "", writer = "", on_offline = "";
        int no = 0, readcnt = 0;
        reader.beginObject();

        while (reader.hasNext()) {
            String readStr = reader.nextName();
            if (readStr.equals("eventnm")) {
                eventnm = reader.nextString();
            } else if (readStr.equals("opar")) {
                opar = reader.nextString();
            } else if (readStr.equals("eventco")) {
                eventco = reader.nextString();
            } else if (readStr.equals("eventstartdate")) {
                eventstartdate = reader.nextString();
            }else if (readStr.equals("eventenddate")) {
                eventenddate = reader.nextString();
            } else if (readStr.equals("eventendtime")) {
                eventendtime = reader.nextString();
            } else if (readStr.equals("eventstarttime")) {
                eventstarttime = reader.nextString();
            } else if (readStr.equals("chrgeinfo")) {
                chrgeinfo = reader.nextString();
            } else if (readStr.equals("mnnst")) {
                mnnst = reader.nextString();
            } else if (readStr.equals("auspcinstt")) {
                auspcinstt = reader.nextString();
            } else if (readStr.equals("phonenumber")) {
                phonenumber = reader.nextString();
            } else if (readStr.equals("suprtinstt")) {
                suprtinstt = reader.nextString();
            } else if (readStr.equals("seatnumber")) {
                seatnumber = reader.nextString();
            } else if (readStr.equals("admfee")) {
                admfee = reader.nextString();
            } else if (readStr.equals("entncage")) {
                entncage = reader.nextString();
            } else if (readStr.equals("dscntinfo")) {
                dscntinfo = reader.nextString();
            } else if (readStr.equals("atpn")) {
                atpn = reader.nextString();
            } else if (readStr.equals("homepageurl")) {
                homepageurl = reader.nextString();
            } else if (readStr.equals("advantkinfo")) {
                advantkinfo = reader.nextString();
            } else if (readStr.equals("prkplceyn")) {
                prkplceyn = reader.nextString();
            } else if (readStr.equals("rdnmadr")) {
                rdnmadr = reader.nextString();
            } else if (readStr.equals("lnmadr")) {
                lnmadr = reader.nextString();
            } else if (readStr.equals("latitude")) {
                latitude = reader.nextString();
            } else if (readStr.equals("longitude")) {
                longitude = reader.nextString();
            } else if (readStr.equals("referencedate")) {
                referencedate = reader.nextString();
            } else if (readStr.equals("filepath")) {
                filepath = ipConfig + "resources/" + reader.nextString();
                Log.d(TAG, "readMessage: filepath => " + filepath);
            } else if (readStr.equals("writer")) {
                writer = reader.nextString();
            } else if (readStr.equals("on_offline")) {
                on_offline = reader.nextString();
            } else if (readStr.equals("no")) {
                no = Integer.parseInt(reader.nextString());
            }else if (readStr.equals("readcnt")) {
                readcnt = Integer.parseInt(reader.nextString());
            } else {
                reader.skipValue();
            }
        }
        reader.endObject();
        return new BoardDTO(eventnm, opar, eventco, eventstartdate, eventenddate, eventstarttime, eventendtime, chrgeinfo, mnnst, auspcinstt, phonenumber,
                suprtinstt, seatnumber, admfee, entncage, dscntinfo, atpn, homepageurl, advantkinfo, prkplceyn, rdnmadr, lnmadr, latitude, longitude, referencedate,
                filepath, writer, on_offline, no, readcnt);
    }
}