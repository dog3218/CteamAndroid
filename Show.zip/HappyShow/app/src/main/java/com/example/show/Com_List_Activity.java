package com.example.show;

import static com.example.show.Common.CommonMethod.isNetworkConnected;
import static com.example.show.Common.CommonMethod.loginDTO;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.show.ATask.BoardSelect;
import com.example.show.ATask.CommunityAllSelect;
import com.example.show.DTO.CommunityDTO;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Com_List_Activity extends AppCompatActivity {
    Toolbar toolbar;


    //커뮤니티 정보 붙여줄 아이템 선언
    ListView listView;
    CommAdapter commAdapter;
    ArrayList<CommunityDTO> dtos;
    String subject = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_com_list);
        super.onCreate(savedInstanceState);


        toolbar = findViewById(R.id.com_list_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);

        // 여기 까지 상단 툴바 --------------------------------------------------------







        //리스트 생성
        dtos = new ArrayList<>();
        listView = findViewById(R.id.com_list_listView);


        // community에서 보낸 subject를 받는 곳!!!!
        Intent intent = getIntent();

        subject = intent.getStringExtra("subject");
        // 툴바 게시판 이름 !!

        if(subject.equals("show")){
            toolbar.setTitle("공연 후기");

        }else if(subject.equals("with")){
            toolbar.setTitle("동행 찾아요");
        }else if(subject.equals("qna")){
            toolbar.setTitle("Q&A");
        }




        // 어댑터 객체 생성
        commAdapter = new CommAdapter(Com_List_Activity.this, dtos);
        listView.setAdapter(commAdapter);




        if(isNetworkConnected(Com_List_Activity.this) == true){
            //AsyncTask 생성
            CommunityAllSelect communityAllSelect = new CommunityAllSelect(dtos, commAdapter, subject);

            try {
                communityAllSelect.execute().get();

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(Com_List_Activity.this, "인터넷에 연결되어 있지 않았습니다", Toast.LENGTH_SHORT).show();
        }


        // listView를 클릭했을 때 이벤트 추가
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // 어떤 값을 선택함
                CommunityDTO dto = (CommunityDTO) commAdapter.getItem(position);
                String nickname = loginDTO.getNickname();
                String email = loginDTO.getEmail();
                Intent intent = new Intent(Com_List_Activity.this, Com_Detail_Activity.class);
                intent.putExtra("dto", dto);
                intent.putExtra("email", email);
                intent.putExtra("nickname", nickname);

                startActivity(intent);

            }
        });
    }
}
