package com.example.show;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.show.DTO.CommunityDTO;

import java.util.ArrayList;

public class CommAdapter extends BaseAdapter {
    private static final String TAG = "com:CommAdapter";

    // 이 어뎁터는 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // List 게시판으로 넘어가는 거에요~~!!!!!!!!!!!!!!---------------------


    Context context;
    ArrayList<CommunityDTO> dtos;

    // 화면을 붙이기 위한 화면 생성
    LayoutInflater inflater;


    public CommAdapter(Context context, ArrayList<CommunityDTO> dtos) {
        this.context = context;
        this.dtos= dtos;

        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }
    // 메소드를 만들 때는 여기서 선언, Comm에서 다룰 것은 커뮤니티 글 삭제 밖에 없으므로 remove만 해준다.-------------------------------
    public void removeComDTO(int position){dtos.clear();dtos.remove(position);

    }


    @Override
    public int getCount() {
        return dtos.size();
    }

    @Override
    public Object getItem(int position) {
        return dtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    // 가장 중요
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "getView: " +  position);

        CommunityViewHolder commViewHolder;

        // 캐시된 뷰가 없을 경우 새로 뷰 홀더를 생성하고 있으면 그 뷰를 재활용 한다.
        if(convertView == null) {
            convertView = inflater.inflate(R.layout.commu_list_item, parent, false);
            // 화면을 새로 만든다.
            commViewHolder = new CommunityViewHolder();

            //붙힌 화면과 아래에 생성한 뷰 홀더를 연결
            commViewHolder.commu_list_no = convertView.findViewById(R.id.commu_list_no);
            commViewHolder.commu_list_title = convertView.findViewById(R.id.commu_list_title);
            commViewHolder.commu_list_readcnt = convertView.findViewById(R.id.commu_list_readcnt);
            commViewHolder.commu_list_layout = convertView.findViewById(R.id.commu_list_layout);

            convertView.setTag(commViewHolder);

        }else {     // 캐시된 뷰가 있을 경우 이미 생성된 뷰 홀더 재 사용
            commViewHolder = (CommunityViewHolder) convertView.getTag();
        }

        // 선택한 dto 데이터를 가져오기
        CommunityDTO dto = dtos.get(position);

        Log.d(TAG, "getView: " + dto.getTitle());


        // 화면에 데이터 연결하기

        commViewHolder.commu_list_no.setText(String.valueOf(dtos.get(position).getId()));
        commViewHolder.commu_list_title.setText(dtos.get(position).getTitle());
        commViewHolder.commu_list_readcnt.setText(String.valueOf(dtos.get(position).getReadcnt()));
        return convertView;
    }

    public class CommunityViewHolder {
        public TextView commu_list_no, commu_list_title, commu_list_readcnt;
        public LinearLayout commu_list_layout;

    }
}
