package com.example.show;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.show.DTO.CommunityDTO;

import java.util.ArrayList;

public class Main_Community extends Fragment {
    Button main_com_btn_review, main_com_btn_with, main_com_btn_Qna;


    // database에서 불러올 adapter, dto, type 선언해준다.
    ArrayList<CommunityDTO> dtos;
    String subject;
    MainActivity activity;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity)getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_community, container, false);

        dtos = new ArrayList<>();
        activity = (MainActivity) getActivity();











        rootView.findViewById(R.id.main_com_btn_review).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "show";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_review_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "show";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        //44, 52번째 줄 엑티비티 생성요망
//-----------------------------------------------------------------------------------------------------
        rootView.findViewById(R.id.main_com_btn_with).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "with";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_with_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "with";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_btn_QnA).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "qna";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);


            }
        });

        rootView.findViewById(R.id.main_com_QnA_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                subject= "qna";
                Intent intent= new Intent(getActivity(), Com_List_Activity.class);
                intent.putExtra("subject",subject);
                startActivity(intent);
            }
        });
//-----------------------------------------------------------------------------------------------------
        return rootView;
    }

}