package com.example.show.DTO;

import java.io.Serializable;

public class ShowDTO implements Serializable {
    private String tile;
    private int regId;
    private char on_offline;

    public ShowDTO(String tile, int regId, char on_offline) {
        this.tile = tile;
        this.regId = regId;
        this.on_offline = on_offline;
    }

    public String getTile() {
        return tile;
    }

    public void setTile(String tile) {
        this.tile = tile;
    }

    public int getRegId() {
        return regId;
    }

    public void setRegId(int regId) {
        this.regId = regId;
    }

    public char getOn_offline() {
        return on_offline;
    }

    public void setOn_offline(char on_offline) {
        this.on_offline = on_offline;
    }
}
