package com.example.show;

import static com.example.show.Common.CommonMethod.BoarDDTO;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.show.DTO.BoardDTO;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

public class InformationActivity extends AppCompatActivity {

    Toolbar toolbar;
    TabLayout tabs;
    BoardDTO info_board_dtos;
    ArrayList<BoardDTO> boardDTOS;

    Fragment info_detail_fragment;
    Fragment info_people_fragment;
    Fragment info_location_fragment;
    Fragment info_qna_fragment;

    Fragment selFragment = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        toolbar = findViewById(R.id.info_toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        toolbar.setTitle("공연정보");
//-----------------------------------------------------------------------------------------------------------//
        Intent intent = getIntent();
        BoarDDTO = (BoardDTO) intent.getSerializableExtra("dto");

        TextView textView = findViewById(R.id.info_textView);
        textView.setText(BoarDDTO.getEventnm());




        // 내가 띄우고 싶은 프레그먼트 선언해 놓은 곳 //------------------
        info_detail_fragment = new Info_Detail();
        info_people_fragment = new Info_Comment();
        info_location_fragment = new Info_Location();
        info_qna_fragment = new Info_QnA();

        getSupportFragmentManager().beginTransaction().replace(R.id.info_contain, info_detail_fragment).commit();



        tabs = findViewById(R.id.tabs_info);
        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                int position = tabs.getSelectedTabPosition();

                if(position == 0){
                    selFragment = info_detail_fragment;
                }else if(position == 1){
                    selFragment = info_people_fragment;
                }else if(position == 2){
                    selFragment = info_location_fragment;
                }else if(position == 3) {
                    selFragment = info_qna_fragment;
                }
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.info_contain, selFragment).commit();

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


    }
}

