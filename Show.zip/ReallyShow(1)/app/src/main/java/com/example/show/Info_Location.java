package com.example.show;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.type.LatLng;

import net.daum.mf.map.api.CameraUpdateFactory;
/*

public class Info_Location extends Fragment implements OnMapReadyCallback {
    private MapView info_map = null;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootview = (ViewGroup) inflater.inflate(R.layout.info_location_fragment, container, false);

        info_map = rootview.findViewById(R.id.info_map);
        info_map.getMapAsync( this);

        return rootview;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //실행 함수
        if(info_map != null) {
            info_map.onCreate(savedInstanceState);
        }
    }

    //지도를 불러오는 메소드
    @Override
    public void onStart() {
        super.onStart();
        info_map.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        info_map.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        info_map.onResume();
    }

    //info_map 설정
    @Override
    public void onMapReady(GoogleMap googleMap) {

        //위도, 경도
        LatLng location = new LatLng(35.1711677,129.1739716);

        //옵션
        MarkerOptions marker = new MarkerOptions();
        marker.position(location);
        marker.title("고운홀");
        marker.snippet("부산광역시 해운대구 좌동 1458-1");

        //맵에 마커 표시, 인포윈도우 표시
        googleMap.addMarker(marker).showInfoWindow();
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(14));


    }
}*/
