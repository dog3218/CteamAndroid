package com.example.show.DTO;

public class MemberDTO {
    private String nickname, password, address, email, idnumber, filename, name, type;


    public MemberDTO(String nickname, String address, String email, String idnumber, String filename, String name,String type) {
        this.nickname = nickname;
        this.address = address;
        this.email = email;
        this.idnumber = idnumber;
        this.filename = filename;
        this.name = name;
        this.type = type;
    }


//회원가입 할 때 모든 정보 저장

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}