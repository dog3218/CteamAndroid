package com.example.show;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.tabs.TabLayout;

public class Main_Home extends Fragment {

    Main_Home_Opera main_home_opera;
    Main_Home_All main_home_all;
    Main_Home_Concert main_home_concert;
    Main_Home_Musical main_home_musical;
    Main_Home_Play main_home_play;
    Main_Home_Exhibition main_home_exhibition;
    Fragment selectFragment= null;

    TabLayout main_home_tabs;
    FrameLayout main_home_contain;

    MainActivity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity= (MainActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_home, container, false);

        main_home_opera = new Main_Home_Opera();
        main_home_concert = new Main_Home_Concert();
        main_home_all = new Main_Home_All();
        main_home_exhibition = new Main_Home_Exhibition();
        main_home_musical = new Main_Home_Musical();
        main_home_play = new Main_Home_Play();

        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();

        main_home_tabs = rootView.findViewById(R.id.main_home_tabs);
        main_home_tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_all).commit();
                        break;
                    case 1:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_musical).commit();
                        break;
                    case 2:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_opera).commit();
                        break;
                    case 3:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_play).commit();
                        break;
                    case 4:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_exhibition).commit();
                        break;
                    case 5:
                        getChildFragmentManager().beginTransaction().replace(R.id.main_home_contain, main_home_concert).commit();
                        break;


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        return rootView;
    }
}
