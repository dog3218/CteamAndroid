package com.example.show.ATask;

import static com.example.show.Common.CommonMethod.ipConfig;

import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

public class IdCheck extends AsyncTask<Integer, Void, Integer> {

    String id;

    public IdCheck(String id) {
        this.id = id;
    }


    String state ="";
    @Override
    protected Integer doInBackground(Integer... integers) {


        // 반드시 선언해야 할것들 : 무조건 해야함  복,붙
        HttpClient httpClient = null;       // 클라이언트 객체
        HttpPost httpPost = null;           // 클라이언트에 붙일 본문
        HttpResponse httpResponse = null;   // 서버에서의 응답받는 부분
        HttpEntity httpEntity = null;       // 응답내용


        try {
            // MultipartEntityBuilder 생성 : 무조건 해야함  복,붙
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.setCharset(Charset.forName("UTF-8"));

            // 여기가 우리가 수정해야 하는 부분 : 서버로 보내는 데이터
            // builder에 문자열 및 데이터 추가하기
            builder.addTextBody("id", id, ContentType.create("Multipart/related", "UTF-8"));


            // 전송
            // 전송 url : 우리가 수정해야 하는 부분
            String postURL = ipConfig + "/anIdCheck";
            // 그대로 사용  복,붙
            InputStream inputStream = null;
            httpClient = AndroidHttpClient.newInstance("Android");
            httpPost = new HttpPost(postURL);
            httpPost.setEntity(builder.build());
            httpResponse = httpClient.execute(httpPost);  // 보내고 응답 받는 부분
            httpEntity = httpResponse.getEntity();    // 응답내용을 저장
            inputStream = httpEntity.getContent();    // 응답내용을 inputStream 에 넣음

            // 응답 처리 : 문자형태로 오는 것을 숫자로 바꾸기// 응답 처리 : 문자열 형태
              BufferedReader bufferedReader = new
              BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
              StringBuilder stringBuilder = new StringBuilder();
              String line = null;
              while ((line = bufferedReader.readLine()) != null){
               stringBuilder.append(line);
               }
                       state = stringBuilder.toString();
             int chk = Integer.parseInt(state);
            inputStream.close();
            return chk;

        }catch (Exception e){
            e.getMessage();
        }finally {
            if(httpEntity != null){
                httpEntity = null;
            }
            if(httpResponse != null){
                httpResponse = null;
            }
            if(httpPost != null){
                httpPost = null;
            }
            if(httpClient != null){
                httpClient = null;
            }
        }


        return 0;
    }
}
