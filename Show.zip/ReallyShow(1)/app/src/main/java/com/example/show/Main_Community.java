package com.example.show;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Main_Community extends Fragment {
    Button main_com_btn_review, main_com_btn_with, main_com_btn_Qna;
    MainActivity activity;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        activity = (MainActivity)getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_community, container, false);

        rootView.findViewById(R.id.main_com_btn_review).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_Show_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_review_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_Show_List_Activity.class);
                startActivity(intent);
            }
        });

        //44, 52번째 줄 엑티비티 생성요망
//-----------------------------------------------------------------------------------------------------
        rootView.findViewById(R.id.main_com_btn_with).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_With_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_with_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_With_List_Activity.class);
                startActivity(intent);
            }
        });

        rootView.findViewById(R.id.main_com_btn_QnA).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_QnA_List_Activity.class);
                startActivity(intent);


            }
        });

        rootView.findViewById(R.id.main_com_QnA_plus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), Com_QnA_List_Activity.class);
                startActivity(intent);
            }
        });
//-----------------------------------------------------------------------------------------------------
        return rootView;
    }

}