package com.example.show;

import static com.example.show.Common.CommonMethod.isNetworkConnected;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.example.show.ATask.MemberSelect;
import com.example.show.DTO.MemberDTO;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class Admin_Member_Activity extends AppCompatActivity {
    Toolbar toolbar;
    RecyclerView recyclerView;
    MemberAdapter memberAdapter;
    ArrayList<MemberDTO> ad_member_dtos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_member);

        toolbar = findViewById(R.id.toolbar_member_list);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        toolbar.setTitle("회원 관리");
        // 여기 까지 상단 툴바 -----------------------------------------------------


        //리사이클러 뷰 시작--------------------------------------


        ad_member_dtos = new ArrayList<>();
        recyclerView = findViewById(R.id.member_list_view);

        LinearLayoutManager layoutManager = new LinearLayoutManager( this, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        // 어댑터 객체를 생성한다
        memberAdapter = new MemberAdapter(Admin_Member_Activity.this,ad_member_dtos);

        recyclerView.setAdapter(memberAdapter);

        if(isNetworkConnected(Admin_Member_Activity.this) == true){
            MemberSelect memberSelect = new MemberSelect(ad_member_dtos, memberAdapter);

            try {
                memberSelect.execute().get();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(Admin_Member_Activity.this, "인터넷에 연결되어 있지 않습니다.", Toast.LENGTH_SHORT).show();
        }



    } //oncreate

}