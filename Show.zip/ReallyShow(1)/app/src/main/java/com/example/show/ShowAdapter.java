package com.example.show;

import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.show.DTO.ShowDTO;

import java.util.ArrayList;

public class ShowAdapter extends BaseAdapter {
    private static final String TAG = "main:SingerAdapter";
    //메인에서 넘겨받을 것 -> 생성자를 만든다.
    Context context;
    ArrayList<ShowDTO> dtos;

    //화면을 붙이기 위한 화면생성
    LayoutInflater inflater;
    AlertDialog dialog;

    public ShowAdapter(Context context, ArrayList<ShowDTO> dtos) {
        this.context = context;
        this.dtos = dtos;

        this.inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
    }

    //=============================================================//
    //메소드를 만들 때는 무조건 여기에 생성한다(adapter)
    //하나의 dto 추가하기 (SingerDTO)
    public void addDto(ShowDTO dto) {
        dtos.add(dto);
    }

    //dtos의 모든 내용 지우기
    public void removeDtos(){
        dtos.clear();
    }
    //=============================================================//


    //dtos에 저장된 dto 개수
    @Override
    public int getCount() {
        return dtos.size();
    }

    //dtos의 특정위치에 있는 dto 가져오기(SingerDTO)
    @Override
    public Object getItem(int position) {
        return dtos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //☆가장 중요☆ : 화면을 생성하고 특정 뷰에 대한 클릭이벤트를 만들 수 있다.
    //만약 화면 5개를 생성한다면 getView가 5번 실행된다.
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d(TAG, "getView: " + position);

        ShowViewHolder viewHolder;


        //캐시된 뷰가 없을 경우 새로 뷰홀더를 생성하고 있으면 그 뷰를 재활용한다.
        if (convertView == null) {
            //화면을 새로 만든다
            convertView = inflater.inflate(R.layout.main_showview, parent, false);

            viewHolder = new ShowViewHolder();
            //붙힌 화면과 아래에 생성한 뷰홀더를 연결한다.
            /*viewHolder.tvName =  convertView.findViewById(R.id.tvName);
            viewHolder.tvMobile =  convertView.findViewById(R.id.tvMobile);*/
            viewHolder.slidePoster = convertView.findViewById(R.id.main_home_slidePoster);

            convertView.setTag(viewHolder);
        }else { //캐시된 뷰가 있을 경우 이미 생성된 뷰홀더를 사용한다.
            viewHolder = (ShowViewHolder) convertView.getTag();
        }

        //선택한 dto 데이터를 가져오기
        ShowDTO dto = dtos.get(position);
        /*String name = dto.getName();
        String mobile = dto.getMobile();*/
        int resImg = dto.getRegId();

        //화면에 데이터를 연결하기
        /*viewHolder.tvName.setText(name);
        viewHolder.tvMobile.setText(mobile);*/
        viewHolder.slidePoster.setImageResource(resImg);


        //이미지 클릭시 이벤트 걸어주기
        viewHolder.slidePoster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "선택 : " + position
                        + "\n이름 : " + dtos.get(position).getTile(),Toast.LENGTH_SHORT).show();

                //이미지뷰를 동적으로 생성해서 해당 이미지 보여줌
                //popUpImg(dtos.get(position).getRegId());
                popUpImgXml(dtos.get(position));
            }
        });

        /*//휴지통 이미지 클릭시 항목 삭제하기
        viewHolder.ivtrash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //특정위치에 있는 항목지우기
                dtos.remove(position);
                //화면 갱신해주기
                notifyDataSetChanged();
            }

        });*/

        return convertView;
    }

    private void popUpImgXml(ShowDTO singerDTO) {
        //1. res에 xml파일을 만든다
        //2. 그 xml파일을 inflate시켜 setView한다

        //팝업창에 xml 붙이기
        LayoutInflater inflater =
                LayoutInflater.from(context);
        //(LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE); = 이 방법도 가능
        //xml에 있는 리소스 찾기
        View view = inflater.inflate(R.layout.main_home_popup, null);
        ImageView imageView = view.findViewById(R.id.main_home_popup);
        /*TextView tvName = view.findViewById(R.id.tvName);
        TextView tvMobile = view.findViewById(R.id.tvMobile);*/
        //xml에 데이터 연결하기
        imageView.setImageResource(singerDTO.getRegId());
        /*tvName.setText(singerDTO.getName());
        tvMobile.setText(singerDTO.getMobile());*/

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("간략히 보기").setView(view);

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        dialog = builder.create();
        dialog.show();
    }

    private void popUpImg(int regId) {
        ImageView imageView = new ImageView(context);
        imageView.setImageResource(regId);

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("이미지 띄우기").setView(imageView);

        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });
        dialog = builder.create();
        dialog.show();
    }

    /*3.xml 파일에서 사용된 모든 변수를 Adapter에서 클래스로 선언한다*/
    public class ShowViewHolder{
        public ImageView slidePoster; //, ivtrash;

        //public TextView tvName, tvMobile;
    }
}

